@theme @theme_boost_union @theme_boost_union_looksettings @theme_boost_union_looksettings_sitebranding
Feature: Configuring the theme_boost_union plugin for the "Site branding" tab on the "Look" page
  In order to use the features
  As admin
  I need to be able to configure the theme Boost Union plugin

  Background:
    Given the following "users" exist:
      | username |
      | student1 |
      | teacher1 |
    And the following "courses" exist:
      | fullname | shortname |
      | Course 1 | C1        |
    And the following "course enrolments" exist:
      | user     | course | role           |
      | teacher1 | C1     | editingteacher |
      | student1 | C1     | student        |

  @javascript @_file_upload
  Scenario: Setting: Logo - Upload a custom logo to the theme
    When I log in as "admin"
    And Behat debugging is disabled
    And I navigate to "Appearance > Boost Union > Look" in site administration
    And I click on "Site branding" "link" in the "#adminsettings .nav-tabs" "css_element"
    And I upload "theme/boost_union/tests/fixtures/moodlelogo.png" file to "Logo" filemanager
    And I press "Save changes"
    And Behat debugging is enabled
    And I log out
    And I click on "Log in" "link" in the ".logininfo" "css_element"
    # We can't check the uploaded image file visually, but we can verify that the compact logo is shipped from the theme_boost_union global logo filearea.
    Then "//div[@id='loginlogo']//img[@id='logoimage'][contains(@src, 'pluginfile.php/1/theme_boost_union/logo')][contains(@src, 'moodlelogo.png')]" "xpath_element" should exist

  @javascript @_file_upload
  Scenario: Setting: Logo - Do not upload a custom logo to the theme (countercheck)
    When I log in as "admin"
    And I log out
    And I click on "Log in" "link" in the ".logininfo" "css_element"
    Then "#loginlogo #logoimage" "css_element" should not exist

  @javascript @_file_upload
  Scenario: Setting: Logo - Upload a custom logo to Moodle core (countercheck)
    When I log in as "admin"
    And I navigate to "Appearance > Logos" in site administration
    And I upload "theme/boost_union/tests/fixtures/moodlelogo.png" file to "Logo" filemanager
    And I log out
    And I click on "Log in" "link" in the ".logininfo" "css_element"
    Then "#loginlogo #logoimage" "css_element" should not exist

  @javascript @_file_upload
  Scenario: Setting: Logo - Upload a PNG logo to the theme and check that it is resized on the server-side
    When I log in as "admin"
    And Behat debugging is disabled
    And I navigate to "Appearance > Boost Union > Look" in site administration
    And I click on "Site branding" "link" in the "#adminsettings .nav-tabs" "css_element"
    And I upload "theme/boost_union/tests/fixtures/moodlelogo.png" file to "Logo" filemanager
    And I press "Save changes"
    And Behat debugging is enabled
    And I log out
    And I click on "Log in" "link" in the ".logininfo" "css_element"
    Then "//div[@id='loginlogo']//img[@id='logoimage'][contains(@src, 'pluginfile.php/1/theme_boost_union/logo/0x200/')][contains(@src, 'moodlelogo.png')]" "xpath_element" should exist

  @javascript @_file_upload
  Scenario: Setting: Logo - Upload a SVG logo to the theme and check that it is not resized on the server-side
    When I log in as "admin"
    And Behat debugging is disabled
    And I navigate to "Appearance > Boost Union > Look" in site administration
    And I click on "Site branding" "link" in the "#adminsettings .nav-tabs" "css_element"
    And I upload "theme/boost_union/tests/fixtures/moodlelogo.svg" file to "Logo" filemanager
    And I press "Save changes"
    And Behat debugging is enabled
    And I log out
    And I click on "Log in" "link" in the ".logininfo" "css_element"
    Then "//div[@id='loginlogo']//img[@id='logoimage'][contains(@src, 'pluginfile.php/1/theme_boost_union/logo/1/')][contains(@src, 'moodlelogo.svg')]" "xpath_element" should exist

  @javascript @_file_upload
  Scenario: Setting: Compact logo - Upload a custom compact logo to the theme
    When I log in as "admin"
    And Behat debugging is disabled
    And I navigate to "Appearance > Boost Union > Look" in site administration
    And I click on "Site branding" "link" in the "#adminsettings .nav-tabs" "css_element"
    And I upload "theme/boost_union/tests/fixtures/moodlelogo.png" file to "Compact logo" filemanager
    And I press "Save changes"
    And Behat debugging is enabled
    And I am on site homepage
    # We can't check the uploaded image file visually, but we can verify that the compact logo is shipped from the theme_boost_union global logo filearea.
    Then "//nav[contains(@class, 'navbar')]//img[contains(@class, 'logo')][contains(@src, 'pluginfile.php/1/theme_boost_union/logocompact')][contains(@src, 'moodlelogo.png')]" "xpath_element" should exist

  @javascript @_file_upload
  Scenario: Setting: Compact logo - Do not upload a custom compact logo to the theme (countercheck)
    When I log in as "admin"
    And I am on site homepage
    Then ".navbar .logo" "css_element" should not exist

  @javascript @_file_upload
  Scenario: Setting: Compact logo - Upload a custom compact logo to Moodle core (countercheck)
    When I log in as "admin"
    And I navigate to "Appearance > Logos" in site administration
    And I upload "theme/boost_union/tests/fixtures/moodlelogo.png" file to "Compact logo" filemanager
    And I am on site homepage
    Then ".navbar .logo" "css_element" should not exist

  @javascript @_file_upload
  Scenario: Setting: Compact logo - Upload a PNG compact logo to the theme and check that it is resized on the server-side
    When I log in as "admin"
    And Behat debugging is disabled
    And I navigate to "Appearance > Boost Union > Look" in site administration
    And I click on "Site branding" "link" in the "#adminsettings .nav-tabs" "css_element"
    And I upload "theme/boost_union/tests/fixtures/moodlelogo.png" file to "Compact logo" filemanager
    And I press "Save changes"
    And Behat debugging is enabled
    And I am on site homepage
    Then "//nav[contains(@class, 'navbar')]//img[contains(@class, 'logo')][contains(@src, 'pluginfile.php/1/theme_boost_union/logocompact/300x300/')][contains(@src, 'moodlelogo.png')]" "xpath_element" should exist

  @javascript @_file_upload
  Scenario: Setting: Compact logo - Upload a SVG compact logo to the theme and check that it is not resized on the server-side
    When I log in as "admin"
    And Behat debugging is disabled
    And I navigate to "Appearance > Boost Union > Look" in site administration
    And I click on "Site branding" "link" in the "#adminsettings .nav-tabs" "css_element"
    And I upload "theme/boost_union/tests/fixtures/moodlelogo.svg" file to "Compact logo" filemanager
    And I press "Save changes"
    And Behat debugging is enabled
    And I am on site homepage
    Then "//nav[contains(@class, 'navbar')]//img[contains(@class, 'logo')][contains(@src, 'pluginfile.php/1/theme_boost_union/logocompact/1/')][contains(@src, 'moodlelogo.svg')]" "xpath_element" should exist

  @javascript @_file_upload
  Scenario: Setting: Favicon - Upload a custom favicon to the theme
    When I log in as "admin"
    And Behat debugging is disabled
    And I navigate to "Appearance > Boost Union > Look" in site administration
    And I click on "Site branding" "link" in the "#adminsettings .nav-tabs" "css_element"
    And I upload "theme/boost_union/tests/fixtures/favicon.ico" file to "Favicon" filemanager
    And I press "Save changes"
    And Behat debugging is enabled
    # We can't check the uploaded favicon visually, but we can verify that the site's favicon is not shipped by pluginfile.php (for uploaded files) and not by theme/image.php (for image files from disk) anymore.
    Then "//head//link[contains(@rel, 'shortcut')][contains(@href, 'pluginfile.php/1/theme_boost_union/favicon')][contains(@href, 'favicon.ico')]" "xpath_element" should exist
    And "//head//link[contains(@rel, 'shortcut')][contains(@href, 'theme/image.php/boost_union')][contains(@href, 'favicon')]" "xpath_element" should not exist

  @javascript @_file_upload
  Scenario: Setting: Favicon - Do not upload a custom favicon to the theme (countercheck)
    When I log in as "admin"
    Then "//head//link[contains(@rel, 'shortcut')][contains(@href, 'theme/image.php/boost_union')][contains(@href, 'favicon')]" "xpath_element" should exist
    And "//head//link[contains(@rel, 'shortcut')][contains(@href, 'pluginfile.php/1/theme_boost_union/favicon')][contains(@href, 'favicon.ico')]" "xpath_element" should not exist

  @javascript @_file_upload
  Scenario: Setting: Favicon - Upload a custom favicon to Moodle core (countercheck)
    When I log in as "admin"
    And I navigate to "Appearance > Logos" in site administration
    And I upload "theme/boost_union/tests/fixtures/favicon.ico" file to "Favicon" filemanager
    And I am on site homepage
    Then "//head//link[contains(@rel, 'shortcut')][contains(@href, 'theme/image.php/boost_union')][contains(@href, 'favicon')]" "xpath_element" should exist
    And "//head//link[contains(@rel, 'shortcut')][contains(@href, 'pluginfile.php/1/theme_boost_union/favicon')][contains(@href, 'favicon.ico')]" "xpath_element" should not exist

  @javascript @_file_upload
  Scenario: Setting: Background image - Upload a background image.
    When I log in as "admin"
    And Behat debugging is disabled
    And I navigate to "Appearance > Boost Union > Look" in site administration
    And I click on "Site branding" "link" in the "#adminsettings .nav-tabs" "css_element"
    And I upload "theme/boost_union/tests/fixtures/login_bg1.png" file to "Background image" filemanager
    And I press "Save changes"
    And Behat debugging is enabled
    And I am on site homepage
    Then DOM element "body" should have computed style "background-size" "cover"
    And DOM element "body" should have background image with file name "login_bg1.png"

  @javascript
  Scenario: Setting: Background image - Do not upload a background image (countercheck).
    When I log in as "admin"
    And I am on site homepage
    Then DOM element "body" should have computed style "background-image" "none"

  @javascript @_file_upload
  Scenario Outline: Setting: Background image - Define the background image position.
    Given the following config values are set as admin:
      | config                  | value      | plugin            |
      | backgroundimageposition | <position> | theme_boost_union |
    When I log in as "admin"
    And Behat debugging is disabled
    And I navigate to "Appearance > Boost Union > Look" in site administration
    And I click on "Site branding" "link" in the "#adminsettings .nav-tabs" "css_element"
    And I upload "theme/boost_union/tests/fixtures/login_bg1.png" file to "Background image" filemanager
    And I press "Save changes"
    And Behat debugging is enabled
    And I am on site homepage
    Then DOM element "body" should have computed style "background-position" "<cssvalue>"

    # We do not want to burn too much CPU time by testing all available options. We just test the default value and one non-default value.
    Examples:
      | position      | cssvalue |
      | center center | 50% 50%  |
      | left top      | 0% 0%    |

  @javascript
  Scenario: Setting: Primary brand color - Set the primary brand color
    Given the following config values are set as admin:
      | config     | value   | plugin            |
      | brandcolor | #FF0000 | theme_boost_union |
    And the following "activities" exist:
      | activity | name      | intro                                                     | course |
      | label    | Label one | <span class="mytesttext text-primary">My test text</span> | C1     |
    And the theme cache is purged and the theme is reloaded
    When I log in as "admin"
    And I am on "Course 1" course homepage
    And I should see "My test text"
    Then DOM element ".mytesttext" should have computed style "color" "rgb(255, 0, 0)"

  @javascript
  Scenario Outline: Setting: Branded gray tones - Set the branded gray tones setting
    Given the following config values are set as admin:
      | config           | value              | plugin            |
      | brandcolor       | #FF0000            | theme_boost_union |
      | brandedgraytones | <brandedgraytones> | theme_boost_union |
    And the following "activities" exist:
      | activity | name      | intro                                                       | course |
      | label    | Label one | <span class="mytesttext text-secondary">My test text</span> | C1     |
    And the theme cache is purged and the theme is reloaded
    When I log in as "admin"
    And I am on "Course 1" course homepage
    And I should see "My test text"
    Then DOM element ".mytesttext" should have computed style "color" "<expectedcolor>"

    Examples:
      | brandedgraytones | expectedcolor      |
      | yes              | rgb(195, 182, 182) |
      |                  | rgb(206, 212, 218) |

  @javascript
  Scenario Outline: Setting: Link color - Set the link color
    Given the following config values are set as admin:
      | config     | value       | plugin            |
      | brandcolor | #FF0000     | theme_boost_union |
      | linkcolor  | <linkcolor> | theme_boost_union |
    And the following "activities" exist:
      | activity | name      | intro                                                               | course |
      | label    | Label one | <a href="#" class="mytestlink">My test link</a>                     | C1     |
      | label    | Label two | <a href="#" class="mytestbutton btn btn-primary">My test button</a> | C1     |
    And the theme cache is purged and the theme is reloaded
    When I log in as "admin"
    And I am on "Course 1" course homepage
    And I should see "My test link"
    Then DOM element ".mytestlink" should have computed style "color" "<expectedcolor>"
    And DOM element ".mytestbutton" should have computed style "background-color" "rgb(255, 0, 0)"

    Examples:
      | linkcolor | expectedcolor  |
      | #00FF00   | rgb(0, 255, 0) |
      |           | rgb(255, 0, 0) |

  @javascript
  Scenario Outline: Setting: Button brand color - Set the button brand color
    Given the following config values are set as admin:
      | config           | value              | plugin            |
      | brandcolor       | #FF0000            | theme_boost_union |
      | buttonbrandcolor | <buttonbrandcolor> | theme_boost_union |
    And the following "activities" exist:
      | activity | name      | intro                                                               | course |
      | label    | Label one | <a href="#" class="mytestlink">My test link</a>                     | C1     |
      | label    | Label two | <a href="#" class="mytestbutton btn btn-primary">My test button</a> | C1     |
    And the theme cache is purged and the theme is reloaded
    When I log in as "admin"
    And I am on "Course 1" course homepage
    And I should see "My test button"
    Then DOM element ".mytestbutton" should have computed style "background-color" "<expectedcolor>"
    And DOM element ".mytestlink" should have computed style "color" "rgb(255, 0, 0)"

    Examples:
      | buttonbrandcolor | expectedcolor  |
      | #00FF00          | rgb(0, 255, 0) |
      |                  | rgb(255, 0, 0) |

  @javascript
  Scenario Outline: Setting: Bootstrap colors - Set the Bootstrap colors
    Given the following config values are set as admin:
      | config               | value      | plugin            |
      | bootstrapcolor<type> | <colorhex> | theme_boost_union |
    And the following "activities" exist:
      | activity | name      | intro                                                    | course |
      | label    | Label one | <span class="mytesttext text-<type>">My test text</span> | C1     |
    And the theme cache is purged and the theme is reloaded
    When I log in as "admin"
    And I am on "Course 1" course homepage
    And I should see "My test text"
    Then DOM element ".mytesttext" should have computed style "color" "<colorrgb>"

    Examples:
      | type    | colorhex | colorrgb         |
      | success | #FF0000  | rgb(255, 0, 0)   |
      | info    | #00FF00  | rgb(0, 255, 0)   |
      | warning | #0000FF  | rgb(0, 0, 255)   |
      | danger  | #FFFF00  | rgb(255, 255, 0) |

  @javascript @_file_upload
  Scenario Outline: Setting: Maximal width of logo in navbar - Set the maximum width
    Given the following config values are set as admin:
      | config       | value     | plugin            |
      | maxlogowidth | <setting> | theme_boost_union |
    And the theme cache is purged and the theme is reloaded
    When I log in as "admin"
    And Behat debugging is disabled
    And I navigate to "Appearance > Boost Union > Look" in site administration
    And I click on "Site branding" "link" in the "#adminsettings .nav-tabs" "css_element"
    And I upload "theme/boost_union/tests/fixtures/moodlelogo.png" file to "Compact logo" filemanager
    And I press "Save changes"
    And Behat debugging is enabled
    And I am on site homepage
    Then DOM element ".navbar-brand" <shouldornot> have computed style "max-width" "<value>"
    And DOM element ".navbar-brand .logo" <shouldornot> have computed style "max-width" "<value>"

    Examples:
      | setting | shouldornot | value |
      |         | should not  | 50px  |
      | 50px    | should      | 50px  |
      | 13%     | should      | 13%   |

  @javascript
  Scenario Outline: Setting: Maximal width of sitename in navbar - Set the maximum width
    Given the following config values are set as admin:
      | config            | value     | plugin            |
      | maxsitenamewidth  | <setting> | theme_boost_union |
    And the theme cache is purged and the theme is reloaded
    When I log in as "admin"
    And I change viewport size to "<viewport>"
    And I am on site homepage
    Then DOM element ".navbar-brand .sitename" <widthshouldornot> have computed style "max-width" "<value>"
    And DOM element ".navbar-brand .sitename" <truncshouldornot> have computed style "text-overflow" "ellipsis"

    Examples:
      | setting | viewport | widthshouldornot | truncshouldornot | value |
      |         | 768x1024 | should not       | should not       | 200px |
      | 200px   | 768x1024 | should           | should           | 200px |
      | 200px   | 375x667  | should not       | should           | 200px |
      | 200px   | 1024x768 | should not       | should           | 200px |

  Scenario Outline: Setting: Navbar color - Set the navbar color
    Given the following config values are set as admin:
      | config      | value     | plugin            |
      | navbarcolor | <setting> | theme_boost_union |
    When I log in as "admin"
    Then the "class" attribute of ".navbar" "css_element" should contain "<classes>"

    Examples:
      | setting      | classes                 |
      | light        | navbar-light bg-white   |
      | dark         | navbar-dark bg-dark     |
      | coloredlight | navbar-light bg-primary |
      | coloreddark  | navbar-dark bg-primary  |

  @javascript
  Scenario Outline: Setting: Navbar tint - Set the navbar tint color (for the colored navbar variants)
    Given the following config values are set as admin:
      | config      | value             | plugin            |
      | navbarcolor | <navbarcolor>     | theme_boost_union |
      | navbartint  | <configuredcolor> | theme_boost_union |
    And the theme cache is purged and the theme is reloaded
    When I log in as "admin"
    # Reloading the page is necessary to ensure that the navbar color is applied, as sometimes it might not appear on the first load due to caching.
    And I reload the page
    Then DOM element ".navbar.bg-primary" should have computed style "background-color" "<expectedcolor>"

    Examples:
      | navbarcolor  | configuredcolor | expectedcolor    |
      | coloredlight | #FF0000         | rgb(255, 0, 0)   |
      | coloreddark  | #FF00FF         | rgb(255, 0, 255) |

  @javascript
  Scenario Outline: Setting: Navbar tint - Do not apply the tint (countercheck for non-colored navbar variants)
    Given the following config values are set as admin:
      | config      | value         | plugin            |
      | navbarcolor | <navbarcolor> | theme_boost_union |
      | navbartint  | #FF0000       | theme_boost_union |
    And the theme cache is purged and the theme is reloaded
    When I log in as "admin"
    # Reloading the page is necessary to ensure that the navbar color is applied, as sometimes it might not appear on the first load due to caching.
    And I reload the page
    Then DOM element ".navbar" should not have computed style "background-color" "rgb(255, 0, 0)"

    Examples:
      | navbarcolor |
      | light       |
      | dark        |

  @javascript
  Scenario: Setting: Navbar tint - Use the primary brand color as fallback when no tint is set
    Given the following config values are set as admin:
      | config      | value        | plugin            |
      | navbarcolor | coloredlight | theme_boost_union |
      | brandcolor  | #FF0000      | theme_boost_union |
      | navbartint  |              | theme_boost_union |
    And the theme cache is purged and the theme is reloaded
    When I log in as "admin"
    # Reloading the page is necessary to ensure that the navbar color is applied, as sometimes it might not appear on the first load due to caching.
    And I reload the page
    Then DOM element ".navbar" should have computed style "background-color" "rgb(255, 0, 0)"
