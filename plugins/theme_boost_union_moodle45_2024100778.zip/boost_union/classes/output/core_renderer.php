<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Theme Boost Union - Core renderer
 *
 * @package    theme_boost_union
 * @copyright  2022 Alexander Bias, lern.link GmbH <alexander.bias@lernlink.de>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace theme_boost_union\output;

use context_course;
use context_system;
use moodle_url;
use stdClass;
use core\di;
use core\hook\manager as hook_manager;
use core\hook\output\before_standard_footer_html_generation;
use core\output\html_writer;
use core_block\output\block_contents;

/**
 * Extending the core_renderer interface.
 *
 * @package    theme_boost_union
 * @copyright  2022 Alexander Bias, lern.link GmbH <alexander.bias@lernlink.de>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class core_renderer extends \theme_boost\output\core_renderer {
    /**
     * Returns the moodle_url for the favicon.
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * It checks if the favicon is overridden in a flavour and, if yes, it serves this favicon.
     * If there isn't a favicon in any flavour set, it serves the general favicon.
     *
     * @since Moodle 2.5.1 2.6
     * @return moodle_url The moodle_url for the favicon
     * @throws \moodle_exception
     */
    public function favicon() {
        global $CFG;

        // Initialize static variable for the flavour favicon as this function might be called (for whatever reason) multiple times
        // during a page output.
        static $hasflavourfavicon, $flavourfaviconurl;

        // If the flavour favicon has already been checked.
        if ($hasflavourfavicon != null) {
            // If there is a flavour favicon.
            if ($hasflavourfavicon == true) {
                // Directly return the flavour favicon.
                return $flavourfaviconurl;
            }
            // Otherwise, if there isn't a flavour favicon, this function will continue to run the logic from Moodle core later.

            // Otherwise.
        } else {
            // Require flavours library.
            require_once($CFG->dirroot . '/theme/boost_union/flavours/flavourslib.php');

            // If any flavour applies to this page.
            $flavour = theme_boost_union_get_flavour_which_applies();
            if ($flavour != null) {
                // If the flavour has a favicon set.
                if ($flavour->look_favicon != null) {
                    // Remember this fact for subsequent runs of this function.
                    $hasflavourfavicon = true;

                    // Compose the URL to the flavour's favicon.
                    $flavourfaviconurl = \core\url::make_pluginfile_url(
                        context_system::instance()->id,
                        'theme_boost_union',
                        'flavours_look_favicon',
                        $flavour->id,
                        '/64x64' .
                        '/' . theme_get_revision(),
                        '/' . $flavour->look_favicon
                    );

                    // Return the URL.
                    return $flavourfaviconurl;

                    // Otherwise.
                } else {
                    // Remember this fact for subsequent runs of this function.
                    $hasflavourfavicon = false;
                }
            }
        }

        // Apparently, there isn't any flavour favicon set. Let's continue with the logic to serve the general favicon.
        $logo = null;
        if (!during_initial_install()) {
            $logo = get_config('theme_boost_union', 'favicon');
        }
        if (empty($logo)) {
            return $this->image_url('favicon', 'theme');
        }

        // Use $CFG->themerev to prevent browser caching when the file changes.
        return moodle_url::make_pluginfile_url(
            context_system::instance()->id,
            'theme_boost_union',
            'favicon',
            '64x64/',
            theme_get_revision(),
            $logo
        );
    }

    /**
     * Return the site's logo URL, if any.
     *
     * This renderer function is copied and modified from /lib/classes/output/renderer_base.php
     *
     * It checks if the logo is overridden in a flavour and, if yes, it serves this logo.
     * If there isn't a logo in any flavour set, it serves the general logo.
     *
     * @param int $maxwidth The maximum width, or null when the maximum width does not matter.
     * @param int $maxheight The maximum height, or null when the maximum height does not matter.
     * @return moodle_url|false
     */
    public function get_logo_url($maxwidth = null, $maxheight = 200) {
        global $CFG;

        // Initialize static variable for the flavour logo as this function might be called (for whatever reason) multiple times
        // during a page output.
        static $hasflavourlogo, $flavourlogourl;

        // If the flavour logo has already been checked.
        if ($hasflavourlogo != null) {
            // If there is a flavour logo.
            if ($hasflavourlogo == true) {
                // Directly return the flavour logo.
                return $flavourlogourl;
            }
            // Otherwise, if there isn't a flavour logo, this function will continue to run the logic from Moodle core later.

            // Otherwise.
        } else {
            // Require flavours library.
            require_once($CFG->dirroot . '/theme/boost_union/flavours/flavourslib.php');

            // If any flavour applies to this page.
            $flavour = theme_boost_union_get_flavour_which_applies();
            if ($flavour != null) {
                // If the flavour has a logo set.
                if ($flavour->look_logo != null) {
                    // Remember this fact for subsequent runs of this function.
                    $hasflavourlogo = true;

                    // Compose the URL to the flavour's logo.
                    $flavourlogourl = \core\url::make_pluginfile_url(
                        context_system::instance()->id,
                        'theme_boost_union',
                        'flavours_look_logo',
                        $flavour->id,
                        '/' . theme_get_revision(),
                        '/' . $flavour->look_logo
                    );

                    // Return the URL.
                    return $flavourlogourl;

                    // Otherwise.
                } else {
                    // Remember this fact for subsequent runs of this function.
                    $hasflavourlogo = false;
                }
            }
        }

        // Apparently, there isn't any flavour logo set. Let's continue to serve the general logo.
        $logo = get_config('theme_boost_union', 'logo');
        if (empty($logo)) {
            return false;
        }

        // If the logo is a SVG image, do not add a size to the path.
        $logoextension = pathinfo($logo, PATHINFO_EXTENSION);
        if (in_array($logoextension, ['svg', 'svgz'])) {
            // The theme_boost_union_pluginfile() function will look for a filepath and will try to extract the size from that.
            // Thus, we cannot drop the filepath from the URL completely.
            // But we can add a path without an 'x' in it which will then be interpreted by theme_boost_union_pluginfile()
            // as "no resize requested".
            $filepath = '1/';

            // Otherwise, add a size to the path.
        } else {
            // 200px high is the default image size which should be displayed at 100px in the page to account for retina displays.
            // It's not worth the overhead of detecting and serving 2 different images based on the device.

            // Hide the requested size in the file path.
            $filepath = ((int) $maxwidth . 'x' . (int) $maxheight) . '/';
        }

        // Use $CFG->themerev to prevent browser caching when the file changes.
        return moodle_url::make_pluginfile_url(
            context_system::instance()->id,
            'theme_boost_union',
            'logo',
            $filepath,
            theme_get_revision(),
            $logo
        );
    }

    /**
     * Return the site's compact logo URL, if any.
     *
     * This renderer function is copied and modified from /lib/classes/output/renderer_base.php
     *
     * It checks if the logo is overridden in a flavour and, if yes, it serves this logo.
     * If there isn't a logo in any flavour set, it serves the general compact logo.
     *
     * @param int $maxwidth The maximum width, or null when the maximum width does not matter.
     * @param int $maxheight The maximum height, or null when the maximum height does not matter.
     * @return moodle_url|false
     */
    public function get_compact_logo_url($maxwidth = 300, $maxheight = 300) {
        global $CFG;

        // Initialize static variable for the flavour logo as this function is called (for whatever reason) multiple times
        // during a page output.
        static $hasflavourlogo, $flavourlogourl;

        // If the flavour logo has already been checked.
        if ($hasflavourlogo != null) {
            // If there is a flavour logo.
            if ($hasflavourlogo == true) {
                // Directly return the flavour logo.
                return $flavourlogourl;
            }
            // Otherwise, if there isn't a flavour logo, this function will continue to run the logic from Moodle core later.

            // Otherwise.
        } else {
            // Require flavours library.
            require_once($CFG->dirroot . '/theme/boost_union/flavours/flavourslib.php');

            // If any flavour applies to this page.
            $flavour = theme_boost_union_get_flavour_which_applies();
            if ($flavour != null) {
                // If the flavour has a compact logo set.
                if ($flavour->look_logocompact != null) {
                    // Remember this fact for subsequent runs of this function.
                    $hasflavourlogo = true;

                    // If the flavour logo is a SVG image, do not add a size to the path.
                    $flavourlogoextension = pathinfo($flavour->look_logocompact, PATHINFO_EXTENSION);
                    if (in_array($flavourlogoextension, ['svg', 'svgz'])) {
                        // The theme_boost_union_pluginfile() function will look for a filepath and will extract the size from that.
                        // If we add a path without an 'x' in it, it will then be interpreted by theme_boost_union_pluginfile()
                        // as "no resize requested".
                        // This mechanism is used for the normal compact logo as well.
                        $flavourfilepath = '1/';

                        // Otherwise, add a size to the path.
                    } else {
                        // Hide the requested size in the file path.
                        $flavourfilepath = ((int)$maxwidth . 'x' . (int)$maxheight) . '/';
                    }

                    // Compose the URL to the flavour's compact logo.
                    $flavourlogourl = \core\url::make_pluginfile_url(
                        context_system::instance()->id,
                        'theme_boost_union',
                        'flavours_look_logocompact',
                        $flavour->id . '/' . $flavourfilepath,
                        theme_get_revision(),
                        '/' . $flavour->look_logocompact
                    );

                    // Return the URL.
                    return $flavourlogourl;

                    // Otherwise.
                } else {
                    // Remember this fact for subsequent runs of this function.
                    $hasflavourlogo = false;
                }
            }
        }

        // Apparently, there isn't any flavour logo set. Let's continue to service the general compact logo.
        $logo = get_config('theme_boost_union', 'logocompact');
        if (empty($logo)) {
            return false;
        }

        // If the logo is a SVG image, do not add a size to the path.
        $logoextension = pathinfo($logo, PATHINFO_EXTENSION);
        if (in_array($logoextension, ['svg', 'svgz'])) {
            // The theme_boost_union_pluginfile() function will look for a filepath and will try to extract the size from that.
            // Thus, we cannot drop the filepath from the URL completely.
            // But we can add a path without an 'x' in it which will then be interpreted by theme_boost_union_pluginfile()
            // as "no resize requested".
            $filepath = '1/';

            // Otherwise, add a size to the path.
        } else {
            // Hide the requested size in the file path.
            $filepath = ((int)$maxwidth . 'x' . (int)$maxheight) . '/';
        }

        // Use $CFG->themerev to prevent browser caching when the file changes.
        return moodle_url::make_pluginfile_url(
            context_system::instance()->id,
            'theme_boost_union',
            'logocompact',
            $filepath,
            theme_get_revision(),
            $logo
        );
    }

    /**
     * Returns HTML attributes to use within the body tag. This includes an ID and classes.
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * @since Moodle 2.5.1 2.6
     * @param string|array $additionalclasses Any additional classes to give the body tag,
     * @return string
     */
    public function body_attributes($additionalclasses = []) {
        global $CFG;

        // Require local libraries.
        require_once($CFG->dirroot . '/theme/boost_union/locallib.php');
        require_once($CFG->dirroot . '/theme/boost_union/flavours/flavourslib.php');

        if (!is_array($additionalclasses)) {
            $additionalclasses = explode(' ', $additionalclasses);
        }

        // If this isn't the login page and the page has a background image, add a class to the body attributes.
        if ($this->page->pagelayout != 'login') {
            if (!empty(get_config('theme_boost_union', 'backgroundimage'))) {
                $additionalclasses[] = 'backgroundimage';
            }
        }

        // If this is the login page and the page has a login background image, add a class to the body attributes.
        if ($this->page->pagelayout == 'login') {
            // Generate the background image class for displaying a random image for the login page.
            $loginimageclass = theme_boost_union_get_random_loginbackgroundimage_class();

            // If the background image class was returned, we can expect that a background image was set.
            // In this case, add both the general loginbackgroundimage class as well as the generated
            // class to the body tag.
            if ($loginimageclass != '') {
                $additionalclasses[] = 'loginbackgroundimage';
                $additionalclasses[] = $loginimageclass;
            }
        }

        // If there is a flavour applied to this page, add the flavour ID as additional body class.
        // Boost Union itself does not need this class for applying the flavour to the page (yet).
        // However, theme designers might want to use it.
        $flavour = theme_boost_union_get_flavour_which_applies();
        if ($flavour != null) {
            $additionalclasses[] = 'flavour' . '-' . $flavour->id;
        }

        // If the admin decided to change the breakpoints of the footer button,
        // add the setting as additional body class.
        // With this setting, we show and hide the footer button as well as move the buttons
        // (back-to-top and communication) which are stacked on top of the footer button upwards.
        $footerbutton = get_config('theme_boost_union', 'enablefooterbutton');
        switch ($footerbutton) {
            case THEME_BOOST_UNION_SETTING_ENABLEFOOTER_NONE:
                $additionalclasses[] = 'theme_boost-union-footerbuttonnone';
                break;
            case THEME_BOOST_UNION_SETTING_ENABLEFOOTER_ALL:
                $additionalclasses[] = 'theme_boost-union-footerbuttonall';
                break;
            case THEME_BOOST_UNION_SETTING_ENABLEFOOTER_MOBILE:
                $additionalclasses[] = 'theme_boost-union-footerbuttonmobile';
                break;
            case THEME_BOOST_UNION_SETTING_ENABLEFOOTER_DESKTOP:
            default:
                $additionalclasses[] = 'theme_boost-union-footerbuttondesktop';
                break;
        }

        // If this is the login page and the page has the accessibility button, add a class to the body attributes.
        // This is currently just needed to make sure in SCSS that the footnote is not covered by the accessibility button.
        if ($this->page->pagelayout == 'login') {
            // If the accessibility button is enabled.
            $enableaccessibilitysupportsetting = get_config('theme_boost_union', 'enableaccessibilitysupport');
            $enableaccessibilitysupportfooterbuttonsetting =
                    get_config('theme_boost_union', 'enableaccessibilitysupportfooterbutton');
            if (
                isset($enableaccessibilitysupportsetting) &&
                    $enableaccessibilitysupportsetting == THEME_BOOST_UNION_SETTING_SELECT_YES &&
                    isset($enableaccessibilitysupportfooterbuttonsetting) &&
                    $enableaccessibilitysupportfooterbuttonsetting == THEME_BOOST_UNION_SETTING_SELECT_YES
            ) {
                // If user login is either not required or if the user is logged in.
                $allowaccessibilitysupportwithoutloginsetting =
                        get_config('theme_boost_union', 'allowaccessibilitysupportwithoutlogin');
                if (
                    !(isset($allowaccessibilitysupportwithoutloginsetting) &&
                        $allowaccessibilitysupportwithoutloginsetting != THEME_BOOST_UNION_SETTING_SELECT_YES) ||
                        (isloggedin() && !isguestuser())
                ) {
                    $additionalclasses[] = 'theme_boost-union-accessibilitybutton';
                }
            }
        }

        return ' id="' . $this->body_id() . '" class="' . $this->body_css_classes($additionalclasses) . '"';
    }

    /**
     * Wrapper for header elements.
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * @return string HTML to display the main header.
     */
    public function full_header() {
        $pagetype = $this->page->pagetype;
        $homepage = get_home_page();
        $homepagetype = null;
        // Add a special case since /my/courses is a part of the /my subsystem.
        if ($homepage == HOMEPAGE_MY || $homepage == HOMEPAGE_MYCOURSES) {
            $homepagetype = 'my-index';
        } else if ($homepage == HOMEPAGE_SITE) {
            $homepagetype = 'site-index';
        }
        if (
            $this->page->include_region_main_settings_in_header_actions() &&
                !$this->page->blocks->is_block_present('settings')
        ) {
            // Only include the region main settings if the page has requested it and it doesn't already have
            // the settings block on it. The region main settings are included in the settings block and
            // duplicating the content causes behat failures.
            $this->page->add_header_action(html_writer::div(
                $this->region_main_settings_menu(),
                'd-print-none',
                ['id' => 'region-main-settings-menu']
            ));
        }

        $header = new stdClass();
        $header->settingsmenu = $this->context_header_settings_menu();
        $header->contextheader = $this->context_header();
        $header->hasnavbar = empty($this->page->layout_options['nonavbar']);
        $header->navbar = $this->navbar();
        $header->pageheadingbutton = $this->page_heading_button();
        $header->courseheader = $this->course_header();
        $header->headeractions = $this->page->get_header_actions();

        // Add the course header image for rendering.
        if (
            $this->page->pagelayout == 'course' && (get_config('theme_boost_union', 'courseheaderimageenabled')
                        == THEME_BOOST_UNION_SETTING_SELECT_YES)
        ) {
            // If course header images are activated, we get the course header image url
            // (which might be the fallback image depending on the course settings and theme settings).
            $header->courseheaderimageurl = theme_boost_union_get_course_header_image_url();
            // Additionally, get the course header image height.
            $header->courseheaderimageheight = get_config('theme_boost_union', 'courseheaderimageheight');
            // Additionally, get the course header image position.
            $header->courseheaderimageposition = get_config('theme_boost_union', 'courseheaderimageposition');
            // Additionally, get the template context attributes for the course header image layout.
            $courseheaderimagelayout = get_config('theme_boost_union', 'courseheaderimagelayout');
            switch ($courseheaderimagelayout) {
                case THEME_BOOST_UNION_SETTING_COURSEIMAGELAYOUT_HEADINGABOVE:
                    $header->courseheaderimagelayoutheadingabove = true;
                    $header->courseheaderimagelayoutstackedclass = '';
                    break;
                case THEME_BOOST_UNION_SETTING_COURSEIMAGELAYOUT_STACKEDDARK:
                    $header->courseheaderimagelayoutheadingabove = false;
                    $header->courseheaderimagelayoutstackedclass = 'dark';
                    break;
                case THEME_BOOST_UNION_SETTING_COURSEIMAGELAYOUT_STACKEDLIGHT:
                    $header->courseheaderimagelayoutheadingabove = false;
                    $header->courseheaderimagelayoutstackedclass = 'light';
                    break;
            }
        }

        if (!empty($pagetype) && !empty($homepagetype) && $pagetype == $homepagetype) {
            $header->welcomemessage = \core\user::welcome_message();
        }
        return $this->render_from_template('core/full_header', $header);
    }

    /**
     * Renders the "breadcrumb" for all pages in boost union.
     *
     * This renderer function is copied and modified from /theme/boost/classes/output/core_renderer.php
     *
     * @return string the HTML for the navbar.
     */
    public function navbar(): string {
        $newnav = new \theme_boost_union\boostnavbar($this->page);
        return $this->render_from_template('core/navbar', $newnav);
    }

    /**
     * Prints a nice side block with an optional header.
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * @param block_contents $bc HTML for the content
     * @param string $region the region the block is appearing in.
     * @return string the HTML to be output.
     */
    public function block(block_contents $bc, $region) {
        global $CFG;

        // Require own locallib.php.
        require_once($CFG->dirroot . '/theme/boost_union/locallib.php');

        $bc = clone($bc); // Avoid messing up the object passed in.
        if (empty($bc->blockinstanceid) || !strip_tags($bc->title)) {
            $bc->collapsible = block_contents::NOT_HIDEABLE;
        }

        $id = !empty($bc->attributes['id']) ? $bc->attributes['id'] : uniqid('block-');
        $context = new stdClass();
        $context->skipid = $bc->skipid;
        $context->blockinstanceid = $bc->blockinstanceid ?: uniqid('fakeid-');
        $context->dockable = $bc->dockable;
        $context->id = $id;
        $context->hidden = $bc->collapsible == block_contents::HIDDEN;
        $context->skiptitle = strip_tags($bc->title);
        $context->showskiplink = !empty($context->skiptitle);
        $context->arialabel = $bc->arialabel;
        $context->ariarole = !empty($bc->attributes['role']) ? $bc->attributes['role'] : '';
        $context->class = $bc->attributes['class'];
        $context->type = $bc->attributes['data-block'];
        $context->title = (string) $bc->title;
        $context->showtitle = $context->title !== '';
        $context->content = $bc->content;
        $context->annotation = $bc->annotation;
        $context->footer = $bc->footer;
        $context->hascontrols = !empty($bc->controls);

        // Hide edit control options for the regions based on the capabilities.
        $regions = theme_boost_union_get_additional_regions();
        $regioncapname = array_search($region, $regions);
        if (!empty($regioncapname) && $context->hascontrols) {
            $context->hascontrols = has_capability('theme/boost_union:editregion' . $regioncapname, $this->page->context);
        }

        if ($context->hascontrols) {
            $context->controls = $this->block_controls($bc->controls, $id);
        }

        return $this->render_from_template('core/block', $context);
    }

    /**
     * Renders the login form.
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * @param \core_auth\output\login $form The renderable.
     * @return string
     */
    public function render_login(\core_auth\output\login $form) {
        global $CFG, $SITE;

        $context = $form->export_for_template($this);

        $context->errorformatted = $this->error_text($context->error);
        $url = $this->get_logo_url();
        if ($url) {
            $url = $url->out(false);
        }
        $context->logourl = $url;
        $context->sitename = format_string(
            $SITE->fullname,
            true,
            ['context' => context_course::instance(SITEID), "escape" => false]
        );

        // Shibboleth internal WAYF: If the Boost Union setting is enabled and if Shibboleth authentication is enabled.
        $context->showshibbolethembeddedwayfcode = false;
        $loginshibbolethinternalwayf = get_config('theme_boost_union', 'loginshibbolethinternalwayf');
        if (
            $loginshibbolethinternalwayf !== false &&
                $loginshibbolethinternalwayf !== THEME_BOOST_UNION_SETTING_SELECT_NO &&
                strpos($CFG->auth, 'shibboleth') !== false &&
                !empty($context->identityproviders)
        ) {
            // If we should replace the Shibboleth IdP button with the IdP selector from auth_shibboleth.
            if ($loginshibbolethinternalwayf === THEME_BOOST_UNION_SETTING_SHIBBOLETH_CONFIG) {
                // Require Shibboleth library.
                require_once($CFG->dirroot . '/auth/shibboleth/auth.php');

                // Get the Shibboleth authentication plugin config.
                get_auth_plugin('shibboleth');
                $shibconfig = get_config('auth_shibboleth');

                // Only show the internal WAYF if the user attribute for IdP selection and the organization selection
                // are configured in Shibboleth.
                if (!empty($shibconfig->user_attribute) && !empty($shibconfig->organization_selection)) {
                    // Get the list of IdPs from Shibboleth and check if there are any IdPs configured.
                    $idplist = get_idp_list($shibconfig->organization_selection);
                    if (!empty($idplist)) {
                        // Compose the WAYF data.
                        // This logic is copied and modified from /auth/shibboleth/login.php.
                        $selectedidp = '-';
                        if (isset($_COOKIE['_saml_idp'])) {
                            $idpcookie = generate_cookie_array($_COOKIE['_saml_idp']);
                            do {
                                $selectedidp = array_pop($idpcookie);
                            } while (!isset($idplist[$selectedidp]) && count($idpcookie) > 0);
                        }
                        $shibbidps = [];
                        foreach ($idplist as $value => $data) {
                            $name = reset($data);
                            $shibbidps[] = [
                                'name' => $name,
                                'value' => $value,
                                'selected' => $value === $selectedidp,
                            ];
                        }
                        $shibbolethloginurl = (new moodle_url('/auth/shibboleth/login.php'))->out(false);
                        $adminemail = get_admin()->email;
                        foreach ($context->identityproviders as $idx => $idp) {
                            $idpurl = $idp['url'] ?? '';
                            if (strpos($idpurl, '/auth/shibboleth/index.php') !== false) {
                                $context->identityproviders[$idx]['useinternalwayf'] = true;
                                $context->identityproviders[$idx]['shibbidps'] = $shibbidps;
                                $context->identityproviders[$idx]['shibbolethloginurl'] = $shibbolethloginurl;
                                $context->identityproviders[$idx]['adminemail'] = $adminemail;
                                $context->identityproviders[$idx]['wayfformid'] = 'login-shibboleth-wayf-' . $idx;
                            }
                        }
                    }
                }

                // Otherwise, if we should replace the Shibboleth IdP button with the configured JavaScript code.
            } else if ($loginshibbolethinternalwayf === THEME_BOOST_UNION_SETTING_SHIBBOLETH_CODE) {
                // Simply use the configured code.
                $loginshibbolethembeddedwayfcode = get_config('theme_boost_union', 'internalshibbolethwayfcode');
                if (!empty($loginshibbolethembeddedwayfcode)) {
                    $context->showshibbolethembeddedwayfcode = true;
                    $context->shibbolethembeddedwayfcode = format_text(
                        $loginshibbolethembeddedwayfcode,
                        FORMAT_HTML,
                        ['trusted' => true, 'noclean' => true, 'filter' => false]
                    );
                }
            }
        }

        // Compute show* flags for all four login types (theme setting + Moodle core).
        // Visibility is controlled in the template via these show* parameters.

        // Local login: theme setting only.
        $loginlocalloginsetting = get_config('theme_boost_union', 'loginlocalloginenable');
        $showlocalloginenabled = ($loginlocalloginsetting != false)
            ? $loginlocalloginsetting
            : THEME_BOOST_UNION_SETTING_SELECT_YES;
        $context->showlocallogin = ($showlocalloginenabled == THEME_BOOST_UNION_SETTING_SELECT_YES);

        // IDP login: theme setting AND core has identity providers.
        $loginidploginenablesetting = get_config('theme_boost_union', 'loginidploginenable');
        $showidploginenabled = ($loginidploginenablesetting != false)
            ? $loginidploginenablesetting
            : THEME_BOOST_UNION_SETTING_SELECT_YES;
        $context->showidplogin = ($showidploginenabled == THEME_BOOST_UNION_SETTING_SELECT_YES) &&
            !empty($context->hasidentityproviders) &&
            !empty($context->identityproviders);

        // Guest login: theme setting AND Moodle core guest login button enabled.
        $loginguestloginenablesetting = get_config('theme_boost_union', 'loginguestloginenable');
        $showguestloginenabled = ($loginguestloginenablesetting != false) ?
            $loginguestloginenablesetting : THEME_BOOST_UNION_SETTING_SELECT_YES;
        $coreguestloginbutton = !empty(get_config('core', 'guestloginbutton'));
        $context->showguestlogin = ($showguestloginenabled == THEME_BOOST_UNION_SETTING_SELECT_YES) &&
            $coreguestloginbutton &&
            !empty($context->canloginasguest);

        // Self registration: theme setting AND Moodle core registerauth configured.
        $loginselfregistrationenablesetting = get_config('theme_boost_union', 'loginselfregistrationenable');
        $showselfregistrationenabled = ($loginselfregistrationenablesetting != false) ?
            $loginselfregistrationenablesetting : THEME_BOOST_UNION_SETTING_SELECT_YES;
        $coreregisterauth = !empty(get_config('core', 'registerauth'));
        $context->showselfregistration = ($showselfregistrationenabled == THEME_BOOST_UNION_SETTING_SELECT_YES)
            && $coreregisterauth
            && !empty($context->cansignup);

        // Compute intro and instruction settings, but only when the corresponding login type is shown.

        // Local login.
        if ($context->showlocallogin) {
            $loginlocalshowintrosetting = get_config('theme_boost_union', 'loginlocalshowintro');
            $showlocalloginintro = ($loginlocalshowintrosetting != false) ?
                $loginlocalshowintrosetting : THEME_BOOST_UNION_SETTING_SELECT_NO;
            if ($showlocalloginintro == THEME_BOOST_UNION_SETTING_SELECT_YES) {
                $context->showlocalloginintro = true;
                $loginlocalintrotext = get_config('theme_boost_union', 'loginlocalintrotext');
                if (!empty($loginlocalintrotext)) {
                    $context->localloginintrotext = format_string($loginlocalintrotext);
                }
            }
            $loginlocalshowinstructionsetting = get_config('theme_boost_union', 'loginlocalshowinstruction');
            $showlocallogininstruction = ($loginlocalshowinstructionsetting != false) ?
                $loginlocalshowinstructionsetting : THEME_BOOST_UNION_SETTING_SELECT_NO;
            if ($showlocallogininstruction == THEME_BOOST_UNION_SETTING_SELECT_YES) {
                $loginlocalinstructions = get_config('theme_boost_union', 'loginlocalinstructioncontent');
                if (isset($loginlocalinstructions) && !empty($loginlocalinstructions)) {
                    $context->showlocallogininstruction = true;
                    $context->locallogininstructions = format_text($loginlocalinstructions, FORMAT_HTML);
                    $loginlocalinstructionposition = get_config('theme_boost_union', 'loginlocalinstructionposition');
                    $context->locallogininstructionposition = ($loginlocalinstructionposition === false) ?
                        THEME_BOOST_UNION_SETTING_LOGININSTRUCTIONPOSITION_BETWEEN : $loginlocalinstructionposition;
                    $context->locallogininstructionsbetween =
                        ($context->locallogininstructionposition === THEME_BOOST_UNION_SETTING_LOGININSTRUCTIONPOSITION_BETWEEN);
                    $context->locallogininstructionsbelow =
                        ($context->locallogininstructionposition === THEME_BOOST_UNION_SETTING_LOGININSTRUCTIONPOSITION_BELOW);
                }
            }
        }

        // IDP login.
        if ($context->showidplogin) {
            $loginidpshowintrosetting = get_config('theme_boost_union', 'loginidpshowintro');
            $showidploginintro = ($loginidpshowintrosetting != false) ?
                $loginidpshowintrosetting : THEME_BOOST_UNION_SETTING_SELECT_YES;
            if ($showidploginintro == THEME_BOOST_UNION_SETTING_SELECT_YES) {
                $context->showidploginintro = true;
                $loginidpintrotext = get_config('theme_boost_union', 'loginidpintrotext');
                if (!empty($loginidpintrotext)) {
                    $context->idploginintrotext = format_string($loginidpintrotext);
                }
            }
            $loginidpshowinstructionsetting = get_config('theme_boost_union', 'loginidpshowinstruction');
            $showidplogininstruction = ($loginidpshowinstructionsetting != false) ?
                $loginidpshowinstructionsetting : THEME_BOOST_UNION_SETTING_SELECT_NO;
            if ($showidplogininstruction == THEME_BOOST_UNION_SETTING_SELECT_YES) {
                $loginidpinstructions = get_config('theme_boost_union', 'loginidpinstructioncontent');
                if (isset($loginidpinstructions) && !empty($loginidpinstructions)) {
                    $context->showidplogininstruction = true;
                    $context->idplogininstructions = format_text($loginidpinstructions, FORMAT_HTML);
                    $loginidpinstructionposition = get_config('theme_boost_union', 'loginidpinstructionposition');
                    $context->idplogininstructionposition = ($loginidpinstructionposition === false) ?
                        THEME_BOOST_UNION_SETTING_LOGININSTRUCTIONPOSITION_BETWEEN : $loginidpinstructionposition;
                    $context->idplogininstructionsbetween =
                        ($context->idplogininstructionposition === THEME_BOOST_UNION_SETTING_LOGININSTRUCTIONPOSITION_BETWEEN);
                    $context->idplogininstructionsbelow =
                        ($context->idplogininstructionposition === THEME_BOOST_UNION_SETTING_LOGININSTRUCTIONPOSITION_BELOW);
                }
            }
        }

        // Guest login.
        if ($context->showguestlogin) {
            $loginguestshowintrosetting = get_config('theme_boost_union', 'loginguestshowintro');
            $showguestloginintro = ($loginguestshowintrosetting != false) ?
                $loginguestshowintrosetting : THEME_BOOST_UNION_SETTING_SELECT_YES;
            if ($showguestloginintro == THEME_BOOST_UNION_SETTING_SELECT_YES) {
                $context->showguestloginintro = true;
                $loginguestintrotext = get_config('theme_boost_union', 'loginguestintrotext');
                if (!empty($loginguestintrotext)) {
                    $context->guestloginintrotext = format_string($loginguestintrotext);
                }
            }
            $loginguestshowinstructionsetting = get_config('theme_boost_union', 'loginguestshowinstruction');
            $showguestlogininstruction = ($loginguestshowinstructionsetting != false) ?
                $loginguestshowinstructionsetting : THEME_BOOST_UNION_SETTING_SELECT_NO;
            if ($showguestlogininstruction == THEME_BOOST_UNION_SETTING_SELECT_YES) {
                $loginguestinstructions = get_config('theme_boost_union', 'loginguestinstructioncontent');
                if (isset($loginguestinstructions) && !empty($loginguestinstructions)) {
                    $context->showguestlogininstruction = true;
                    $context->guestlogininstructions = format_text($loginguestinstructions, FORMAT_HTML);
                    $loginguestinstructionposition = get_config('theme_boost_union', 'loginguestinstructionposition');
                    $context->guestlogininstructionposition = ($loginguestinstructionposition === false) ?
                        THEME_BOOST_UNION_SETTING_LOGININSTRUCTIONPOSITION_BETWEEN : $loginguestinstructionposition;
                    $context->guestlogininstructionsbetween =
                        ($context->guestlogininstructionposition === THEME_BOOST_UNION_SETTING_LOGININSTRUCTIONPOSITION_BETWEEN);
                    $context->guestlogininstructionsbelow =
                        ($context->guestlogininstructionposition === THEME_BOOST_UNION_SETTING_LOGININSTRUCTIONPOSITION_BELOW);
                }
            }
        }

        // Self registration.
        if ($context->showselfregistration) {
            $loginselfregistrationshowintrosetting = get_config('theme_boost_union', 'loginselfregistrationshowintro');
            $showselfregistrationloginintro = ($loginselfregistrationshowintrosetting != false) ?
                $loginselfregistrationshowintrosetting : THEME_BOOST_UNION_SETTING_SELECT_YES;
            if ($showselfregistrationloginintro == THEME_BOOST_UNION_SETTING_SELECT_YES) {
                $context->showselfregistrationloginintro = true;
                $loginselfregistrationintrotext = get_config('theme_boost_union', 'loginselfregistrationintrotext');
                if (!empty($loginselfregistrationintrotext)) {
                    $context->selfregistrationloginintrotext = format_string($loginselfregistrationintrotext);
                }
            }
            $loginselfregistrationshowinstructionsetting = get_config('theme_boost_union', 'loginselfregistrationshowinstruction');
            $showselfregistrationlogininstruction = ($loginselfregistrationshowinstructionsetting != false) ?
                $loginselfregistrationshowinstructionsetting : THEME_BOOST_UNION_SETTING_SELECT_NO;
            if ($showselfregistrationlogininstruction == THEME_BOOST_UNION_SETTING_SELECT_YES) {
                $loginselfregistrationinstructions = get_config('theme_boost_union', 'loginselfregistrationinstructioncontent');
                if (isset($loginselfregistrationinstructions) && !empty($loginselfregistrationinstructions)) {
                    $context->showselfregistrationlogininstruction = true;
                    $context->selfregistrationlogininstructions = format_text($loginselfregistrationinstructions, FORMAT_HTML);
                    $loginselfregistrationinstructionposition =
                            get_config('theme_boost_union', 'loginselfregistrationinstructionposition');
                    $context->selfregistrationlogininstructionposition = ($loginselfregistrationinstructionposition === false) ?
                        THEME_BOOST_UNION_SETTING_LOGININSTRUCTIONPOSITION_BETWEEN : $loginselfregistrationinstructionposition;
                    $context->selfregistrationlogininstructionsbetween =
                        ($context->selfregistrationlogininstructionposition ===
                            THEME_BOOST_UNION_SETTING_LOGININSTRUCTIONPOSITION_BETWEEN);
                    $context->selfregistrationlogininstructionsbelow =
                        ($context->selfregistrationlogininstructionposition ===
                            THEME_BOOST_UNION_SETTING_LOGININSTRUCTIONPOSITION_BELOW);
                }
            }
        }

        // Get and use login layout setting.
        $loginlayoutsetting = get_config('theme_boost_union', 'loginlayout');
        $loginlayout = ($loginlayoutsetting != false) ? $loginlayoutsetting : THEME_BOOST_UNION_SETTING_LOGINLAYOUT_VERTICAL;
        $context->loginlayout = $loginlayout;

        // Set template marker for each layout type.
        $context->loginlayoutaccordion = ($loginlayout == THEME_BOOST_UNION_SETTING_LOGINLAYOUT_ACCORDION) ? true : false;
        $context->loginlayouttabs = ($loginlayout == THEME_BOOST_UNION_SETTING_LOGINLAYOUT_TABS) ? true : false;
        $context->loginlayoutvertical = ($loginlayout == THEME_BOOST_UNION_SETTING_LOGINLAYOUT_VERTICAL) ? true : false;

        $loginidpsplitsetting = get_config('theme_boost_union', 'loginidpsplit');
        $separateidppertab = (($loginidpsplitsetting !== false)
            ? $loginidpsplitsetting : THEME_BOOST_UNION_SETTING_SELECT_NO) === THEME_BOOST_UNION_SETTING_SELECT_YES;
        // Create sorted login methods array.
        // This ensures the DOM order matches the visual order, so CSS :first-of-type and :last-of-type work correctly.
        // Note: The template uses the same loop structure for all layouts, with conditionals for tabs vs vertical/accordion.
        $loginmethods = [];

        // Local login.
        if ($context->showlocallogin) {
            $order = get_config('theme_boost_union', 'loginorderlocal');
            if ($order === false) {
                $order = 1; // Default order.
            }
            $loginmethods[] = (object)[
                'id' => 'login-method-local',
                'name' => 'local',
                'order' => $order,
                'type' => 'local',
                'islocal' => true,
                'isidp' => false,
                'isfirsttimesignup' => false,
                'isguest' => false,
                'isfirst' => false,
            ];
        }

        // IDP login.
        if ($context->showidplogin) {
            $order = get_config('theme_boost_union', 'loginorderidp');
            if ($order === false) {
                $order = 2; // Default order.
            }
            // If the setting to separate IDPs per tab is enabled and if there are identity providers.
            if ($separateidppertab && !empty($context->identityproviders)) {
                // Create a separate login method for each IDP, so they can be rendered in separate tabs.
                // Preserve the original order of the IDPs as provided by Moodle core.
                $providers = array_values($context->identityproviders);
                foreach ($providers as $idx => $idp) {
                    $loginmethods[] = (object)[
                        'id' => 'login-method-idp-' . $idx,
                        'name' => 'idp',
                        'order' => $order,
                        'type' => 'idp',
                        'islocal' => false,
                        'isidp' => true,
                        'isfirsttimesignup' => false,
                        'isguest' => false,
                        'isfirst' => false,
                        'idpsplit' => true,
                        'idpsplitfirst' => ($idx === 0),
                        'identityproviders' => [$idp],
                        'idpidx' => $idx,
                    ];
                }

                // Otherwise, create a single login method for all IDPs,
                // so they can be rendered in a single tab or an accordion pane.
            } else {
                $loginmethods[] = (object)[
                    'id' => 'login-method-idp',
                    'name' => 'idp',
                    'order' => $order,
                    'type' => 'idp',
                    'islocal' => false,
                    'isidp' => true,
                    'isfirsttimesignup' => false,
                    'isguest' => false,
                    'isfirst' => false,
                ];
            }
        }

        // Self registration.
        if ($context->showselfregistration) {
            $order = get_config('theme_boost_union', 'loginorderfirsttimesignup');
            if ($order === false) {
                $order = 3; // Default order.
            }
            $loginmethods[] = (object)[
                'id' => 'login-method-firsttimesignup',
                'name' => 'firsttimesignup',
                'order' => $order,
                'type' => 'firsttimesignup',
                'islocal' => false,
                'isidp' => false,
                'isfirsttimesignup' => true,
                'isguest' => false,
                'isfirst' => false,
            ];
        }

        // Guest login.
        if ($context->showguestlogin) {
            $order = get_config('theme_boost_union', 'loginorderguest');
            if ($order === false) {
                $order = 4; // Default order.
            }
            $loginmethods[] = (object)[
                'id' => 'login-method-guest',
                'name' => 'guest',
                'order' => $order,
                'type' => 'guest',
                'islocal' => false,
                'isidp' => false,
                'isfirsttimesignup' => false,
                'isguest' => true,
                'isfirst' => false,
            ];
        }

        // Sort login methods by order setting.
        usort($loginmethods, function ($a, $b) {
            // Sort by order value first.
            $orderby = $a->order <=> $b->order;

            // If order values are different, use that for sorting.
            if ($orderby !== 0) {
                return $orderby;
            }

            // Otherwise, if order values are equal, sort by identity-provider order.
            // This covers as well the case when the admin configured the same order value for multiple login methods
            // as the spaceship operator also returns 0 when both operands are null/undefined
            // (which is the case for non-IDP methods that don't have an idpidx).
            return ($a->idpidx ?? 0) <=> ($b->idpidx ?? 0);
        });

        // Mark the first method in the sorted array.
        if (!empty($loginmethods)) {
            $loginmethods[0]->isfirst = true;
        }

        // Set login method labels:
        // - For IDP login methods with IDP split enabled, use the name of the first (or only) IDP as the label.
        // - For all other methods, use the corresponding tab label setting if tabs or accordion layout is enabled.
        // Otherwise use no label.

        // Determine if tab labels should be used based on the layout type.
        $usetablabels = $loginlayout == THEME_BOOST_UNION_SETTING_LOGINLAYOUT_TABS
            || $loginlayout == THEME_BOOST_UNION_SETTING_LOGINLAYOUT_ACCORDION;

        // Prepare an array of login method keys and their corresponding tab label config names and default strings.
        // If tab labels are not used for the current layout, this will be an empty array and the loop below will be skipped.
        $logintablabelconfigs = $usetablabels ? [
            'local' => [
                'config' => 'loginlocalloginlabel',
                'default' => 'loginlocalloginlabelsetting_default',
            ],
            'idp' => [
                'config' => 'loginidploginlabel',
                'default' => 'loginidploginlabelsetting_default',
            ],
            'firsttimesignup' => [
                'config' => 'loginselfregistrationloginlabel',
                'default' => 'loginselfregistrationloginlabelsetting_default',
            ],
            'guest' => [
                'config' => 'loginguestloginlabel',
                'default' => 'loginguestloginlabelsetting_default',
            ],
        ] : [];

        // Iterate over the login methods and set the label for each method based on the rules described above.
        foreach ($loginmethods as $method) {
            // For IDP login methods with IDP split enabled, use the name of the first (or only) IDP as the label.
            if (!empty($method->idpsplit)) {
                $idp = $method->identityproviders[0];
                $rawname = is_array($idp) ? ($idp['name'] ?? '') : ($idp->name ?? '');
                $method->label = format_string($rawname);
                continue;
            }

            // For all other methods, if tab labels are used for the current layout, use the corresponding tab label setting.
            // Otherwise use no label.
            if (!$usetablabels) {
                continue;
            }
            $labelconfig = $logintablabelconfigs[$method->name] ?? null;
            if ($labelconfig !== null) {
                $label = format_string(get_config('theme_boost_union', $labelconfig['config']));
                if ($label === false || $label === '') {
                    $label = format_string(get_string($labelconfig['default'], 'theme_boost_union'));
                }
            } else {
                $label = '';
            }
            $method->label = $label;
        }

        // Determine the active/primary login method.
        $primarylogin = get_config('theme_boost_union', 'primarylogin');
        if ($primarylogin === false) {
            $primarylogin = 'none';
        }
        // Set active method based on layout type.
        // For tabs: primarylogin match, or first if primarylogin is 'none'.
        // For accordion: primarylogin match only (no default to first).
        // For vertical: no active flags.
        foreach ($loginmethods as $method) {
            if ($loginlayout == THEME_BOOST_UNION_SETTING_LOGINLAYOUT_TABS) {
                // Tabs: Default to first method when primarylogin is 'none'.
                // If IDP split is enabled, also consider the idpsplitfirst flag for IDP methods.
                if (!empty($method->idpsplit)) {
                    $method->active = ($primarylogin === 'none' && $method->isfirst) ||
                        ($primarylogin === 'idp' && !empty($method->idpsplitfirst));
                } else {
                    $method->active = ($primarylogin === $method->name) || ($primarylogin === 'none' && $method->isfirst);
                }
            } else if ($loginlayout == THEME_BOOST_UNION_SETTING_LOGINLAYOUT_ACCORDION) {
                // Accordion: Only set active if matched, no default to first.
                // If IDP split is enabled, also consider the idpsplitfirst flag for IDP methods.
                if (!empty($method->idpsplit)) {
                    $method->active = ($primarylogin === 'idp' && !empty($method->idpsplitfirst));
                } else {
                    $method->active = ($primarylogin === $method->name);
                }
            } else {
                // Vertical layout: no active flags.
                $method->active = false;
            }
        }

        // Add the loginmethods to the template context.
        $context->loginmethods = $loginmethods;

        // Add global login instructions.
        $logininstructionsabove = get_config('theme_boost_union', 'logininstructionsabove');
        if (!empty($logininstructionsabove)) {
            $context->logininstructionsabove = format_text($logininstructionsabove, FORMAT_HTML);
        }
        $logininstructionsbelow = get_config('theme_boost_union', 'logininstructionsbelow');
        if (!empty($logininstructionsbelow)) {
            $context->logininstructionsbelow = format_text($logininstructionsbelow, FORMAT_HTML);
        }

        // Add JS if the tabs layout is active and enhanced tabs layout behaviour is enabled.
        $loginenhancedtabslayout = get_config('theme_boost_union', 'loginenhancedtabslayout');
        if ($context->loginlayouttabs && $loginenhancedtabslayout == THEME_BOOST_UNION_SETTING_SELECT_YES) {
            $this->page->requires->js_call_amd('theme_boost_union/logintabs', 'init');
        }

        // Render the login form template with the context.
        return $this->render_from_template('core/loginform', $context);
    }

    /**
     * Content that should be output in the footer area
     * of the page. Designed to be called in theme layout.php files.
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * @return string HTML fragment.
     */
    public function standard_footer_html() {
        global $CFG;

        // Initialize static variable to store the output for subsequent runs of this function
        // (we call it at least twice from footer.mustache).
        static $output;

        // If the output has already been generated.
        if ($output != null) {
            // Return it directly.
            return $output;
        }

        if (during_initial_install()) {
            // Debugging info can not work before install is finished,
            // in any case we do not want any links during installation!
            return '';
        }

        // Require own locallib.php.
        require_once($CFG->dirroot . '/theme/boost_union/locallib.php');

        // Check if there are any footersuppressstandardfooter_ settings set to YES.
        // If not, we can use the standard Moodle core hook dispatch mechanism for better performance.
        // We cache this check in the application cache to avoid iterating over hundreds of Boost Union settings on every page load.
        $cache = \cache::make('theme_boost_union', 'hooksuppress');
        $cachedhashooksuppresssettings = $cache->get('hashooksuppresssettings');

        // If the cache is empty, call the helper function to check all settings and cache the result.
        if ($cachedhashooksuppresssettings === false) {
            $hashooksuppresssettings = theme_boost_union_reset_hooksuppress_cache();
        } else {
            // Convert cached integer back to boolean.
            $hashooksuppresssettings = (bool)$cachedhashooksuppresssettings;
        }

        // If there are no suppressed footer settings, use the standard Moodle core renderer mechanism.
        if (!$hashooksuppresssettings) {
            // Create the hook and dispatch it normally.
            $hook = new before_standard_footer_html_generation($this);
            $hook->process_legacy_callbacks();
            di::get(hook_manager::class)->dispatch($hook);

            // Gather the output.
            $output = $hook->get_output();

            // Otherwise, we need to suppress specific plugin outputs.
        } else {
            // Process the hooks as defined by Moodle core.
            // But, instead of letting Moodle core dispatch the hook and call all callbacks,
            // we create an empty hook and manually call only the callbacks which are not suppressed by Boost Union
            // or by $CFG->hooks_callback_overrides. This is the only way to suppress specific plugin outputs in the footer
            // without modifying the plugins themselves.
            $hook = new before_standard_footer_html_generation($this);

            // Get all callbacks for this hook.
            $callbacks = di::get(hook_manager::class)->get_callbacks_for_hook(
                'core\\hook\\output\\before_standard_footer_html_generation'
            );

            // Iterate over all callbacks and call only those which are not suppressed.
            foreach ($callbacks as $callback) {
                // Check if the callback is disabled via $CFG->hooks_callback_overrides.
                if (theme_boost_union_is_callback_disabled_in_config($callback['callback'])) {
                    // Skip this callback as it's disabled in config.php.
                    continue;
                }

                // Extract the pluginname.
                $pluginname = theme_boost_union_get_pluginname_from_callbackname($callback);

                // Check if the given plugin's output is suppressed by Boost Union's settings.
                $suppresssetting = get_config('theme_boost_union', 'footersuppressstandardfooter_' . $pluginname);

                // If the plugin's output is NOT suppressed by Boost Union.
                if (!isset($suppresssetting) || $suppresssetting != THEME_BOOST_UNION_SETTING_SELECT_YES) {
                    // Call the callback manually.
                    call_user_func($callback['callback'], $hook);
                }
            }

            // Give plugins an opportunity to add any footer elements (for legacy plugins).
            // Originally, this is realized with $hook->process_legacy_callbacks();
            // However, we duplicate the code here and use the logic from Boost Union which has been used there up to v4.3.
            // Get the array of plugins with the standard_footer_html() function which can be suppressed by Boost Union.
            $pluginswithfunction = get_plugins_with_function(function: 'standard_footer_html', migratedtohook: true);
            // Iterate over all plugins.
            foreach ($pluginswithfunction as $plugintype => $plugins) {
                foreach ($plugins as $pluginname => $function) {
                    // If the given plugin's output is suppressed by Boost Union's settings.
                    $suppresssetting = get_config('theme_boost_union', 'footersuppressstandardfooter_' . $plugintype . '_' .
                            $pluginname);
                    if (isset($suppresssetting) && $suppresssetting == THEME_BOOST_UNION_SETTING_SELECT_YES) {
                        // Skip the plugin.
                        continue;

                        // Otherwise.
                    } else {
                        // Add the output.
                        $hook->add_html($function());
                    }
                }
            }

            // Gather the output.
            $output = $hook->get_output();
        }

        // If the theme switcher links are not suppressed by Boost Union's settings.
        $suppressthemeswitchsetting = get_config('theme_boost_union', 'footersuppressthemeswitch');
        if (!isset($suppressthemeswitchsetting) || $suppressthemeswitchsetting == THEME_BOOST_UNION_SETTING_SELECT_NO) {
            if ($this->page->devicetypeinuse == 'legacy') {
                // The legacy theme is in use print the notification.
                $output .= html_writer::tag('div', get_string('legacythemeinuse'), ['class' => 'legacythemeinuse']);
            }

            // Get links to switch device types (only shown for users not on a default device).
            $output .= $this->theme_switch_links();
        }

        return $output;
    }

    /**
     * Returns course-specific information to be output immediately above content on any course page
     * (for the current course)
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * It is based on the standard_end_of_body_html() function but was split into two parts
     * (for the additionalhtmlfooter and the unique endtoken) to be requested individually in footer.mustache
     * in Boost Union.
     *
     * @param bool $onlyifnotcalledbefore output content only if it has not been output before
     * @return string
     */
    public function course_content_header_notifications($onlyifnotcalledbefore = false) {
        static $functioncalled = false;
        if ($functioncalled && $onlyifnotcalledbefore) {
            // We have already output the notifications.
            return '';
        }

        // Output any session notification.
        $notifications = \core\notification::fetch();

        $bodynotifications = '';
        foreach ($notifications as $notification) {
            $bodynotifications .= $this->render_from_template(
                $notification->get_template_name(),
                $notification->export_for_template($this)
            );
        }

        $output = html_writer::span($bodynotifications, 'notifications', ['id' => 'user-notifications']);

        $functioncalled = true;

        return $output;
    }

    /**
     * Returns course-specific information to be output immediately above content on any course page
     * (for the current course)
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * It is based on the standard_end_of_body_html() function but was split into two parts
     * (for the additionalhtmlfooter and the unique endtoken) to be requested individually in footer.mustache
     * in Boost Union.
     *
     * @param bool $onlyifnotcalledbefore output content only if it has not been output before
     * @return string
     */
    public function course_content_header_coursecontent($onlyifnotcalledbefore = false) {
        global $CFG;

        static $functioncalled = false;
        if ($functioncalled && $onlyifnotcalledbefore) {
            // We have already output the course content header.
            return '';
        }

        $output = '';

        if ($this->page->course->id == SITEID) {
            // Return immediately and do not include /course/lib.php if not necessary.
            return $output;
        }

        require_once($CFG->dirroot . '/course/lib.php');
        $functioncalled = true;
        $courseformat = course_get_format($this->page->course);
        if (($obj = $courseformat->course_content_header()) !== null) {
            $output .= html_writer::div($courseformat->get_renderer($this->page)->render($obj), 'course-content-header');
        }
        return $output;
    }

    /**
     * The standard tags (typically script tags that are not needed earlier) that
     * should be output after everything else. Designed to be called in theme layout.php files.
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * It is based on the standard_end_of_body_html() function but was split into two parts
     * (for the additionalhtmlfooter and the unique endtoken) to be requested individually in footer.mustache
     * in Boost Union.
     *
     * @return string HTML fragment.
     */
    public function standard_end_of_body_html_endtoken() {
        // This function is normally called from a layout.php file in core_renderer::header()
        // but some of the content won't be known until later, so we return a placeholder
        // for now. This will be replaced with the real content in core_renderer::footer().
        $output = $this->unique_end_html_token;
        return $output;
    }

    /**
     * The standard tags (typically script tags that are not needed earlier) that
     * should be output after everything else. Designed to be called in theme layout.php files.
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * It is based on the standard_end_of_body_html() function but was split into two parts
     * (for the additionalhtmlfooter and the unique endtoken) to be requested individually in footer.mustache
     * in Boost Union.
     *
     * @return string HTML fragment.
     */
    public function standard_end_of_body_html_additionalhtmlfooter() {
        global $CFG;

        // Initialize static variable to store the output for subsequent runs of this function
        // (we call it at least twice from footer.mustache).
        static $output;

        // If the output has already been generated.
        if ($output != null) {
            // Return it directly.
            return $output;
        }

        $output = '';
        if ($this->page->pagelayout !== 'embedded' && !empty($CFG->additionalhtmlfooter)) {
            // The following code is part of Moodle core from Moodle 5.2 on (MDL-88210 / MDL-85498).
            // It was backported to Boost Union to allow admins to use that feature already on legacy versions.

            // The additional HTML footer content needs to also support JS so it supports things like analytics or other tooling.
            // It is controlled via config so is considered trusted for this.
            // We use format_text rather than injecting directly, to support features like multi-lang.
            $formatoptions = [
                'trusted' => true,
                'clean' => false,
                'context' => $this->page->context,
                'para' => false,
                'allowid' => true,
            ];
            $output .= "\n" . format_text($CFG->additionalhtmlfooter, FORMAT_HTML, $formatoptions);
        }
        return $output;
    }

    /**
     * Start output by sending the HTTP headers, and printing the HTML <head>
     * and the start of the <body>.
     *
     * To control what is printed, you should set properties on $PAGE.
     *
     * @return string HTML that you must output this, preferably immediately.
     */
    public function header() {
        global $CFG, $SESSION, $USER;

        // Get the header output from the parent class.
        $output = parent::header();

        // If the admin decided to suppress the login info in the footer,
        // the 'failed login attempts' counter in the navbar will not be reset as this is only done by the
        // user_count_login_failures() function from the login_info() function which is not called anymore in this case.
        //
        // The header() function calls the user_count_login_failures() function as well, but does not set the parameter
        // to reset the failed login attempts counter (see issue #658 for details).
        // So we call the user_count_login_failures() function here with the reset parameter set to true here to ensure that the
        // failed login attempts counter is reset anyway when the footer is suppressed.
        //
        // As an alternative to this approach, we could have overwritten the header() function completely here, just changing
        // the line calling the user_count_login_failures(). This would have resulted in a mainantenance overhead
        // and would not have had any performance benefits as the original Moodle calls user_count_login_failures() twice as well.
        $footersuppresslogininfosetting = get_config('theme_boost_union', 'footersuppresslogininfo');
        if (isset($footersuppresslogininfosetting) && $footersuppresslogininfosetting == THEME_BOOST_UNION_SETTING_SELECT_YES) {
            if (isset($SESSION->justloggedin) && !empty($CFG->displayloginfailures)) {
                require_once($CFG->dirroot . '/user/lib.php');
                user_count_login_failures($USER, true);
            }
        }

        // Return the parent header() output.
        return $output;
    }

    /**
     * Get the course pattern datauri to show on a course card.
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * @param int $id Id to use when generating the pattern
     * @return string datauri or URL to fallback image
     */
    public function get_generated_image_for_id($id) {
        // Get the course overview image source setting.
        $imagesource = get_config('theme_boost_union', 'courseoverviewimagesource');

        // If not set, use the default (course image with pattern fallback).
        if (!$imagesource) {
            $imagesource = THEME_BOOST_UNION_SETTING_COURSEOVERVIEWIMAGESOURCE_COURSEPLUSPATTERN;
        }

        // Handle the different image source options.
        switch ($imagesource) {
            // Option 1: Course image with pattern fallback (default Moodle behavior).
            case THEME_BOOST_UNION_SETTING_COURSEOVERVIEWIMAGESOURCE_COURSEPLUSPATTERN:
                return parent::get_generated_image_for_id($id);

            // Option 2: Course image with fallback image.
            case THEME_BOOST_UNION_SETTING_COURSEOVERVIEWIMAGESOURCE_COURSEPLUSFALLBACK:
                // This function is called only if there is no course image and the caller is requesting
                // the course pattern image as fallback. We do not need to check for the course image here,
                // just return the fallback image instead of the pattern.

                // Try to get and return the fallback image.
                $fallbackimageurl = theme_boost_union_get_course_overview_fallback_image_url();
                if ($fallbackimageurl !== null) {
                    return $fallbackimageurl->out();
                }
                // If no fallback image is configured, use the pattern.
                return parent::get_generated_image_for_id($id);

            // Default fallback.
            default:
                return parent::get_generated_image_for_id($id);
        }
    }

    /**
     * Returns a string containing a link to the user documentation.
     * Also contains an icon by default. Shown to teachers and admin only.
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * @param string $path The page link after doc root and language, no leading slash.
     * @param string $text The text to be displayed for the link
     * @param boolean $forcepopup Whether to force a popup regardless of the value of $CFG->doctonewwindow
     * @param array $attributes htm attributes
     * @return string
     */
    public function doc_link($path, $text = '', $forcepopup = false, array $attributes = []) {
        global $CFG;

        // Set the icon only if the setting is not set to suppress the footer icons.
        $footericonsetting = get_config('theme_boost_union', 'footersuppressicons');
        if (!isset($footericonsetting) || $footericonsetting == THEME_BOOST_UNION_SETTING_SELECT_NO) {
            $icon = $this->pix_icon('book', '', 'moodle');

            // Otherwise.
        } else {
            $icon = null;
        }

        $attributes['href'] = new moodle_url(get_docs_url($path));
        $newwindowicon = '';
        if (!empty($CFG->doctonewwindow) || $forcepopup) {
            $attributes['target'] = '_blank';
            $newwindowicon = $this->pix_icon(
                'i/externallink',
                get_string('opensinnewwindow'),
                'moodle',
                ['class' => 'fa fa-externallink fa-fw']
            );
        }

        return html_writer::tag('a', $icon . $text . $newwindowicon, $attributes);
    }

    /**
     * Returns the services and support link for the help pop-up.
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * @return string
     */
    public function services_support_link(): string {
        global $CFG;

        if (
            during_initial_install() ||
            (isset($CFG->showservicesandsupportcontent) && $CFG->showservicesandsupportcontent == false) ||
            !is_siteadmin()
        ) {
            return '';
        }

        // Set the icon only if the setting is not set to suppress the footer icons.
        $footericonsetting = get_config('theme_boost_union', 'footersuppressicons');
        if (!isset($footericonsetting) || $footericonsetting == THEME_BOOST_UNION_SETTING_SELECT_NO) {
            $liferingicon = $this->pix_icon('t/life-ring', '', 'moodle', ['class' => 'fa fa-life-ring']);

            // Otherwise.
        } else {
            $liferingicon = null;
        }

        $newwindowicon = $this->pix_icon('i/externallink', get_string('opensinnewwindow'), 'moodle', ['class' => 'ms-1']);
        $link = !empty($CFG->servicespage)
            ? $CFG->servicespage
            : 'https://moodle.com/help/?utm_source=CTA-banner&utm_medium=platform&utm_campaign=name~Moodle4+cat~lms+mp~no';
        $content = $liferingicon . get_string('moodleservicesandsupport') . $newwindowicon;

        return html_writer::tag('a', $content, ['target' => '_blank', 'href' => $link]);
    }

    /**
     * Returns the HTML for the site support email link
     *
     * This renderer function is copied and modified from /lib/classes/output/core_renderer.php
     *
     * @param array $customattribs Array of custom attributes for the support email anchor tag.
     * @param bool $embed Set to true if you want to embed the link in other inline content.
     * @return string The html code for the support email link.
     */
    public function supportemail(array $customattribs = [], bool $embed = false): string {
        global $CFG;

        // Do not provide a link to contact site support if it is unavailable to this user. This would be where the site has
        // disabled support, or limited it to authenticated users and the current user is a guest or not logged in.
        if (
            !isset($CFG->supportavailability) ||
                $CFG->supportavailability == CONTACT_SUPPORT_DISABLED ||
                ($CFG->supportavailability == CONTACT_SUPPORT_AUTHENTICATED && (!isloggedin() || isguestuser()))
        ) {
            return '';
        }

        $label = get_string('contactsitesupport', 'admin');

        // Set the icon only if the setting is not set to suppress the footer icons.
        $footericonsetting = get_config('theme_boost_union', 'footersuppressicons');
        if (!isset($footericonsetting) || $footericonsetting == THEME_BOOST_UNION_SETTING_SELECT_NO) {
            $icon = $this->pix_icon('book', '', 'moodle');

            // Otherwise.
        } else {
            $icon = null;
        }

        // Set the icon only if the setting is no set to suppress the footer icons.
        if (isset($footericonsetting) && $footericonsetting != THEME_BOOST_UNION_SETTING_SELECT_YES) {
            $icon = $this->pix_icon('t/email', '');
        }

        if (!$embed) {
            $content = $icon . $label;
        } else {
            $content = $label;
        }

        if (!empty($CFG->supportpage)) {
            $attributes = ['href' => $CFG->supportpage, 'target' => 'blank'];
            $content .= $this->pix_icon('i/externallink', '', 'moodle', ['class' => 'ms-1']);
        } else {
            $attributes = ['href' => $CFG->wwwroot . '/user/contactsitesupport.php'];
        }

        $attributes += $customattribs;

        return html_writer::tag('a', $content, $attributes);
    }
}
