export const HELP_URL_LEVELS = "https://docs.levelup.plus/xp/docs/levels";
