---
name: Question
about: Question about the format
title: ''
labels: Question
assignees: gjb2048

---

Please use this when you have a general question about the format that is not a bug, enhancement / improvement or support.

**Versions (please complete the following information):**
 - Moodle: [e.g. 4.1]
 - Format: [e.g. 401.1.0]
 - Browser and version [e.g. Chrome Version 108.0.5359.125 (Official Build) (64-bit) on Windows 10]
