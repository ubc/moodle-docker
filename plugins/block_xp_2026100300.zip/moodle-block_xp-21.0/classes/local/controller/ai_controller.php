<?php
// This file is part of Level Up XP.
//
// Level Up XP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Level Up XP is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Level Up XP.  If not, see <https://www.gnu.org/licenses/>.
//
// See <https://levelup.plus>.

namespace block_xp\local\controller;

use block_xp\di;
use html_writer;

/**
 * AI page controller.
 *
 * @package    block_xp
 * @copyright  2026 Frédéric Massart
 * @author     Frédéric Massart <fred@branchup.tech>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class ai_controller extends page_controller {
    /** @var string The route name. */
    protected $routename = 'ai';

    /**
     * Redirect when AI promotion is unavailable.
     *
     * @return void
     */
    protected function pre_content() {
        if (!di::get('addon')->is_promo_allowed()) {
            return $this->redirect($this->navigator->get_url('infos'));
        }
    }

    /**
     * Get the browser page title.
     *
     * @return string
     */
    protected function get_page_html_head_title() {
        return get_string('ai', 'block_xp');
    }

    /**
     * Get the page heading.
     *
     * @return string
     */
    protected function get_page_heading() {
        return get_string('ai', 'block_xp');
    }

    /**
     * Output the AI promotion content.
     *
     * @return void
     */
    protected function page_content() {
        $renderer = $this->get_renderer();
        $promourl = $this->navigator->get_url('promo')->out(false);

        $output = $this->get_renderer();
        echo $output->advanced_heading(get_string('aipagetitle', 'block_xp'), [
            'intro' => get_string('aipageintro', 'block_xp'),
            'help' => new \help_icon('aipagetitle', 'block_xp'),
        ]);

        echo html_writer::start_div('xp-mt-4');
        echo $renderer->notification_without_close(get_string('unlockfeaturewithxpplus', 'block_xp', $promourl), 'info');
        echo html_writer::end_div();
    }
}
