<?php
// This file is part of Level Up XP.
//
// Level Up XP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Level Up XP is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Level Up XP.  If not, see <https://www.gnu.org/licenses/>.
//
// See <https://levelup.plus>.

namespace block_xp\local\rule;

/**
 * Instance.
 *
 * @package    block_xp
 * @copyright  2024 Frédéric Massart
 * @author     Frédéric Massart <fred@branchup.tech>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class static_instance implements instance_with_source {
    /** @var object The record. */
    protected $record;
    /** @var \context The context. */
    protected $context;
    /** @var \context The childcontext. */
    protected $childcontext;

    /**
     * Constructor.
     *
     * @param object $record The record.
     */
    public function __construct($record) {
        $this->record = $record;
    }

    /**
     * Get ID.
     *
     * @return int
     */
    public function get_id(): int {
        return $this->record->id;
    }

    /**
     * Get the source rule ID.
     *
     * @return int|null
     */
    public function get_source_rule_id(): ?int {
        return isset($this->record->sourceruleid) ? (int) $this->record->sourceruleid : null;
    }

    /**
     * Get context.
     *
     * @return \context
     */
    public function get_context(): \context {
        if (!isset($this->context)) {
            // An empty context ID means a default rule, report it as the system context.
            $this->context = \context::instance_by_id($this->record->contextid ?: SYSCONTEXTID, IGNORE_MISSING);
            if (!$this->context) {
                debugging("Context {$this->record->contextid} not found, falling back to system context", DEBUG_DEVELOPER);
                $this->context = \context_system::instance();
            }
        }
        return $this->context;
    }

    /**
     * Get child context.
     *
     * @return \context|null
     */
    public function get_child_context(): ?\context {
        if (!$this->record->childcontextid) {
            return null;
        }
        if (!isset($this->childcontext)) {
            $this->childcontext = \context::instance_by_id($this->record->childcontextid, IGNORE_MISSING);
            if (!$this->childcontext) {
                debugging("Child context {$this->record->childcontextid} not found, ignoring...", DEBUG_DEVELOPER);
            }
        }
        return $this->childcontext ?: null;
    }

    /**
     * Get points.
     *
     * @return int
     */
    public function get_points(): int {
        return $this->record->points;
    }

    /**
     * Get type name.
     *
     * @return string
     */
    public function get_type_name(): string {
        return $this->record->type;
    }

    /**
     * Get filter name.
     *
     * @return string
     */
    public function get_filter_name(): string {
        return $this->record->filter;
    }

    /**
     * Get filter config.
     *
     * @return object
     */
    public function get_filter_config(): object {
        return (object) [
            'courseid' => $this->record->filtercourseid,
            'cmid' => $this->record->filtercmid,
            'int1' => $this->record->filterint1,
            'char1' => $this->record->filterchar1,
        ];
    }
}
