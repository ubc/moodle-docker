<?php
// This file is part of Level Up XP.
//
// Level Up XP is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Level Up XP is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Level Up XP.  If not, see <https://www.gnu.org/licenses/>.
//
// See <https://levelup.plus>.

namespace block_xp\local\reason;

/**
 * Reason.
 *
 * A reason for a thing.
 *
 * @package    block_xp
 * @copyright  2017 Frédéric Massart
 * @author     Frédéric Massart <fred@branchup.tech>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
interface reason {
    /**
     * Get a signature.
     *
     * @return string
     * @deprecated Since XP 20
     */
    public function get_signature();

    /**
     * Get the type.
     *
     * @return string
     * @deprecated Since XP 20, use resolver instead.
     */
    public static function get_type();

    /**
     * Reloads the object from its signature.
     *
     * @param string $signature The signature.
     * @deprecated Since XP 20
     * @return self
     */
    public static function from_signature($signature);
}
