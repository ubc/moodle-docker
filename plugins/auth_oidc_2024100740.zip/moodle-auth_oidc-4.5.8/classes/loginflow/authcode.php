<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Authorization Code login flow.
 *
 * @package auth_oidc
 * @author James McQuillan <james.mcquillan@remote-learner.net>
 * @author Lai Wei <lai.wei@enovation.ie>
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @copyright (C) 2014 onwards Microsoft, Inc. (http://microsoft.com/)
 */

namespace auth_oidc\loginflow;

use auth_oidc\event\user_authed;
use auth_oidc\event\user_created;
use auth_oidc\event\user_rename_attempt;
use auth_oidc\jwt;
use auth_oidc\utils;
use core\context\system;
use core\output\notification;
use core_text;
use core_user;
use moodle_exception;
use core\url;
use stdClass;
use core\di;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/auth/oidc/lib.php');
require_once($CFG->dirroot . '/user/lib.php');

/**
 * Login flow for the oauth2 authorization code grant.
 */
class authcode extends base {
    /**
     * Returns a list of potential IdPs that this authentication plugin supports. Used to provide links on the login page.
     *
     * @param string $wantsurl The relative url fragment the user wants to get to.
     * @return array Array of IdPs.
     */
    public function loginpage_idp_list($wantsurl) {
        if (!auth_oidc_is_setup_complete()) {
            return [];
        }
        $showicon = isset($this->config->set_pix) ? $this->config->set_pix : true;
        $name = strip_tags(format_text($this->config->opname));
        $idpentry = [
            'url' => new url('/auth/oidc/', ['source' => 'loginpage']),
            'name' => $name,
        ];
        if ($showicon) {
            global $OUTPUT;
            if (!empty($this->config->customicon)) {
                $idpentry['iconurl'] = $OUTPUT->image_url('0/customicon', 'auth_oidc')->out(false);
            } else {
                $icon = (!empty($this->config->icon)) ? $this->config->icon : 'auth_oidc:microsoft_365';
                $icon = explode(':', $icon);
                if (isset($icon[1])) {
                    [$iconcomponent, $iconname] = $icon;
                } else {
                    $iconcomponent = 'auth_oidc';
                    $iconname = 'microsoft_365';
                }
                $idpentry['iconurl'] = $OUTPUT->image_url($iconname, $iconcomponent)->out(false);
            }
            $idpentry['name'] = $name;
        }
        return [$idpentry];
    }

    /**
     * Validate that a URL is local to this Moodle installation.
     *
     * @param string $urlstring The URL to validate (as string).
     * @return bool True if URL is safe to use as a redirect destination.
     */
    protected function is_valid_local_url(string $urlstring): bool {
        global $CFG;

        // Parse both URLs to compare components reliably.
        $wwwroot = parse_url($CFG->wwwroot);
        $checkurl = parse_url($urlstring);

        if (!$wwwroot || !$checkurl) {
            return false;
        }

        // Scheme and host must match exactly.
        if (($wwwroot['scheme'] ?? '') !== ($checkurl['scheme'] ?? '')) {
            return false;
        }
        if (($wwwroot['host'] ?? '') !== ($checkurl['host'] ?? '')) {
            return false;
        }

        // Port must match if present.
        if (($wwwroot['port'] ?? null) !== ($checkurl['port'] ?? null)) {
            return false;
        }

        // Path must start with the wwwroot path (handles subdirectory installs).
        $wwwrootpath = rtrim($wwwroot['path'] ?? '', '/') . '/';
        $checkpath = $checkurl['path'] ?? '/';
        if (strpos($checkpath . '/', $wwwrootpath) !== 0) {
            return false;
        }

        return true;
    }

    /**
     * Get an OIDC parameter.
     *
     * Validates the parameter against visible ASCII characters (0x21-0x7E), excluding spaces.
     * While RFC 6749 allows VSCHAR (0x20-0x7E), we exclude space for practical URL parsing safety.
     * This allows authorization codes from any RFC-compliant OIDC provider that uses visible ASCII.
     *
     * @param string $name The name of the parameter.
     * @param string $fallback The fallback value.
     * @return string The parameter value, or fallback.
     */
    protected function getoidcparam($name, $fallback = '') {
        $val = optional_param($name, $fallback, PARAM_RAW);
        $val = trim($val);
        $valclean = preg_replace('/[^\x21-\x7E]/', '', $val);
        if ($valclean !== $val) {
            utils::debug('Authorization error.', __METHOD__, $name);
            throw new moodle_exception('errorauthgeneral', 'auth_oidc');
        }
        return $valclean;
    }

    /**
     * Handle requests to the redirect URL.
     *
     * @return mixed Determined by loginflow.
     */
    public function handleredirect() {
        global $CFG, $SESSION;

        $error = optional_param('error', '', PARAM_TEXT);
        $errordescription = optional_param('error_description', '', PARAM_TEXT);
        $silentloginmode = get_config('auth_oidc', 'silentloginmode');
        $selectaccount = false;
        if ($silentloginmode) {
            if ($error == 'login_required') {
                // If silent login mode is enabled and the error is 'login_required', redirect to the login page.
                $loginpageurl = new url('/login/index.php', ['noredirect' => 1]);
                redirect($loginpageurl);
                die();
            } else if ($error == 'interaction_required') {
                if (strpos($errordescription, 'multiple user identities') !== false) {
                    $selectaccount = true;
                } else {
                    $loginpageurl = new url('/login/index.php', ['noredirect' => 1]);
                    redirect($loginpageurl);
                    die();
                }
            }
        }

        if (get_config('auth_oidc', 'idptype') == AUTH_OIDC_IDP_TYPE_MICROSOFT_IDENTITY_PLATFORM) {
            $adminconsent = optional_param('admin_consent', '', PARAM_TEXT);
            if ($adminconsent) {
                $state = $this->getoidcparam('state');
                if (!empty($state)) {
                    $requestparams = [
                        'state' => $state,
                        'error_description' => optional_param('error_description', '', PARAM_TEXT),
                    ];
                    $this->handlecertadminconsentresponse($requestparams);
                }
            }
        }

        $state = $this->getoidcparam('state');
        $code = $this->getoidcparam('code');
        $promptlogin = (bool)optional_param('promptlogin', 0, PARAM_BOOL);
        $promptaconsent = (bool)optional_param('promptaconsent', 0, PARAM_BOOL);
        $justauth = (bool)optional_param('justauth', 0, PARAM_BOOL);
        if (!empty($state) && $selectaccount === false) {
            $requestparams = [
                'state' => $state,
                'code' => $code,
                'error_description' => optional_param('error_description', '', PARAM_TEXT),
            ];
            // Response from OP.
            $this->handleauthresponse($requestparams);
        } else {
            if (isloggedin() && !isguestuser() && empty($justauth) && empty($promptaconsent)) {
                if (isset($SESSION->wantsurl) && $this->is_valid_local_url($SESSION->wantsurl)) {
                    $urltogo = $SESSION->wantsurl;
                    unset($SESSION->wantsurl);
                } else {
                    $urltogo = new url('/');
                }
                redirect($urltogo);
                die();
            }
            // Handle guest account session termination.
            if (isguestuser()) {
                \core\session\manager::terminate_current();
            }
            // Initial login request.
            $stateparams = ['forceflow' => 'authcode'];
            if (!empty($SESSION->wantsurl)) {
                // Normalize to string in case it's a core\url object.
                $wantsurl = ($SESSION->wantsurl instanceof url) ? $SESSION->wantsurl->out() : (string)$SESSION->wantsurl;
                // Validate URL is local using safe domain comparison.
                if ($this->is_valid_local_url($wantsurl)) {
                    $stateparams['wantsurl'] = $wantsurl;
                }
            }
            $extraparams = [];
            if ($promptaconsent === true) {
                $extraparams = ['prompt' => 'admin_consent'];
            }
            if ($justauth === true) {
                $stateparams['justauth'] = true;
            }
            $this->initiateauthrequest($promptlogin, $stateparams, $extraparams, $selectaccount);
        }
    }

    /**
     * This is the primary method that is used by the authenticate_user_login() function in moodlelib.php.
     *
     * @param string $username The username (with system magic quotes)
     * @param string $password The password (with system magic quotes)
     * @return bool Authentication success or failure.
     */
    public function user_login($username, $password = null) {
        global $CFG, $DB;

        // Check user exists.
        $userfilters = ['username' => $username, 'mnethostid' => $CFG->mnet_localhost_id, 'auth' => 'oidc'];
        $userexists = $DB->record_exists('user', $userfilters);

        // Check token exists.
        $tokenrec = $DB->get_record('auth_oidc_token', ['username' => $username]);
        $code = optional_param('code', null, PARAM_RAW);
        $tokenvalid = (!empty($tokenrec) && !empty($code) && $tokenrec->authcode === $code) ? true : false;
        return ($userexists === true && $tokenvalid === true) ? true : false;
    }

    /**
     * Initiate an authorization request to the configured OP.
     *
     * @param bool $promptlogin Whether to prompt for login or use existing session.
     * @param array $stateparams Parameters to store as state.
     * @param array $extraparams Additional parameters to send with the OIDC request.
     * @param bool $selectaccount Whether to prompt the user to select an account.
     */
    public function initiateauthrequest(
        $promptlogin = false,
        array $stateparams = [],
        array $extraparams = [],
        bool $selectaccount = false
    ) {
        global $USER;

        if (isloggedin() && !isguestuser()) {
            // Record who initiated this request against the state record. The OIDC callback can arrive as a
            // cross-site POST (response_mode=form_post), which a SameSite=Lax session cookie is not sent on, so the
            // session may not survive the round trip. Storing the user id here lets handleauthresponse() identify
            // the initiating user from the (unguessable, single-use) state record instead of the live session.
            $stateparams['initiatinguserid'] = $USER->id;
        }

        $this->set_csrf_cookie();
        $client = $this->get_oidcclient();
        $client->authrequest($promptlogin, $stateparams, $extraparams, $selectaccount);
    }

    /**
     * Initiaite an admin consent request when using Microsoft Identity Platform.
     *
     * @param array $stateparams
     * @param array $extraparams
     * @return void
     */
    public function initiateadminconsentrequest(array $stateparams = [], array $extraparams = []) {
        global $USER;

        if (!isset($stateparams['initiatinguserid']) && isloggedin() && !isguestuser()) {
            $stateparams['initiatinguserid'] = $USER->id;
        }

        $this->set_csrf_cookie();
        $client = $this->get_oidcclient();
        $client->adminconsentrequest($stateparams, $extraparams);
    }

    /**
     * Handle a login state that could not be matched to a stored state record.
     *
     * This normally happens when the user takes longer than the state record's lifetime to
     * complete login at the identity provider (for example, while approving a multi-factor
     * authentication prompt), so the scheduled cleanup task has already deleted the record by
     * the time the identity provider redirects back. When the "stateredirect_enabled" setting is
     * on, this shows a customizable, friendly message and automatically redirects the user back
     * to the login page instead of surfacing the generic Moodle error page.
     *
     * @return never
     * @throws moodle_exception If the friendly redirect setting is disabled.
     */
    protected function handlemissingstaterecord(): never {
        global $OUTPUT, $PAGE;

        if (empty(get_config('auth_oidc', 'stateredirect_enabled'))) {
            throw new moodle_exception('errorauthunknownstate', 'auth_oidc');
        }

        $PAGE->set_url('/auth/oidc/');
        $PAGE->set_context(system::instance());
        $PAGE->set_pagelayout('redirect');
        $PAGE->set_title(get_string('pageshouldredirect'));

        $message = get_config('auth_oidc', 'stateredirect_message');
        if (empty($message)) {
            $message = get_string('errorauthunknownstate', 'auth_oidc');
        }
        $message = format_text($message, FORMAT_HTML, ['context' => system::instance()]);

        $delay = (int) get_config('auth_oidc', 'stateredirect_delay');
        if ($delay < 0) {
            $delay = 0;
        }

        $url = new url('/login/index.php');

        echo $OUTPUT->redirect_message($url->out(), $message, $delay, false, notification::NOTIFY_ERROR);
        exit;
    }

    /**
     * Set a dedicated CSRF cookie (SameSite=None; Secure) before redirecting to the IdP.
     *
     * The main session cookie carries SameSite=Lax (MDL-83526), which browsers drop on
     * cross-site form_post callbacks, so a separate cookie is required to carry the sesskey.
     */
    protected function set_csrf_cookie(): void {
        global $CFG;
        // Always attempt to set the cookie with the Secure flag: browsers on plain HTTP will
        // simply refuse to store it (safe no-op), while HTTPS terminated by a reverse proxy that
        // Moodle isn't aware of (missing $CFG->sslproxy) will still honour it correctly.
        $cookiepath = parse_url($CFG->wwwroot, PHP_URL_PATH) ?: '/';
        setcookie('auth_oidc_csrf', sesskey(), [
            'expires' => time() + 5 * MINSECS,
            'path' => $cookiepath,
            'secure' => true,
            'httponly' => true,
            'samesite' => 'None',
        ]);
    }

    /**
     * Clear the CSRF cookie set by set_csrf_cookie().
     *
     * Public so that \auth_oidc\observers::handle_user_loggedout() can clear a stale cookie
     * when a user logs out while an OIDC request is still pending.
     */
    public function clear_csrf_cookie(): void {
        global $CFG;
        setcookie('auth_oidc_csrf', '', [
            'expires' => time() - HOURSECS,
            'path' => parse_url($CFG->wwwroot, PHP_URL_PATH) ?: '/',
            'secure' => true,
            'httponly' => true,
            'samesite' => 'None',
        ]);
    }

    /**
     * Verify the state record's sesskey against the CSRF cookie, falling back to the current
     * session's sesskey when the cookie is absent. Always clears the cookie and, on failure,
     * deletes the state record.
     *
     * @param stdClass $staterec
     * @throws moodle_exception if the CSRF check fails.
     */
    protected function verify_csrf_cookie(stdClass $staterec): void {
        global $DB;

        $csrfcookie = $_COOKIE['auth_oidc_csrf'] ?? null;
        $csrftoken = (is_string($csrfcookie) && $csrfcookie !== '') ? $csrfcookie : sesskey();
        $valid = hash_equals((string) $staterec->sesskey, (string) $csrftoken);

        $this->clear_csrf_cookie();

        if (!$valid) {
            $DB->delete_records('auth_oidc_state', ['id' => $staterec->id]);
            utils::debug(
                $csrfcookie === null ? 'CSRF cookie missing on OIDC callback.' : 'CSRF cookie mismatch on OIDC callback.',
                __METHOD__,
                ['staterecid' => $staterec->id]
            );
            throw new moodle_exception('errorauthunknownstate', 'auth_oidc');
        }
    }

    /**
     * Handles the response for certificate-based admin consent authorization.
     *
     * @param array $authparams Array of authorization parameters.
     * @return void
     * @throws moodle_exception
     */
    protected function handlecertadminconsentresponse(array $authparams) {
        global $CFG, $DB, $SESSION;

        if (!empty($authparams['error_description'])) {
            utils::debug('Authorization error.', __METHOD__, $authparams);
            redirect($CFG->wwwroot, get_string('errorauthgeneral', 'auth_oidc'), null, notification::NOTIFY_ERROR);
        }

        if (!isset($authparams['state'])) {
            utils::debug('No state received.', __METHOD__, $authparams);
            $this->handlemissingstaterecord();
        }

        // Validate and expire state.
        $staterec = $DB->get_record('auth_oidc_state', ['state' => $authparams['state']]);
        if (empty($staterec)) {
            $this->handlemissingstaterecord();
        }

        $csrfverified = is_https() || !empty($CFG->sslproxy) || !empty($_COOKIE['auth_oidc_csrf']);
        if ($csrfverified) {
            $this->verify_csrf_cookie($staterec);
        }

        $orignonce = $staterec->nonce;
        $additionaldata = [];
        if (!empty($staterec->additionaldata)) {
            $additionaldata = @unserialize($staterec->additionaldata);
            if (!is_array($additionaldata)) {
                $additionaldata = [];
            }
        }
        $SESSION->stateadditionaldata = $additionaldata;
        $DB->delete_records('auth_oidc_state', ['id' => $staterec->id]);

        // Re-associate the browser session with the admin who initiated the consent request before doing
        // anything that might fail below, so a failure in the auto-detection step (see below) does not leave
        // the admin looking logged out on the resulting page.
        if ($csrfverified && !empty($additionaldata['initiatinguserid'])) {
            $initiatinguser = core_user::get_user((int) $additionaldata['initiatinguserid']);
            if (
                $initiatinguser && empty($initiatinguser->deleted) &&
                (!isloggedin() || isguestuser())
            ) {
                \core\session\manager::login_user($initiatinguser);
            }
        }

        // Get token. This app-only token is only used to auto-detect the Microsoft Entra tenant and OneDrive for
        // Business URL settings below; admin consent itself has already been granted by Microsoft Entra by this
        // point. Conditional Access policies can block this specific app-only token request (AADSTS53003) even
        // though consent succeeded, and the tenant/URL can still be auto-detected via other Graph API calls, so
        // that failure is not fatal and is silently redirected past.
        $client = $this->get_oidcclient();
        try {
            $tokenparams = $client->app_access_token_request();
        } catch (moodle_exception $e) {
            if ($e->errorcode === 'settings_adminconsent_error_53003' && $e->module === 'local_o365') {
                redirect($e->link);
            }
            throw $e;
        }
        if (!isset($tokenparams['access_token'])) {
            throw new moodle_exception('errorauthnoaccesstoken', 'auth_oidc');
        }

        $eventdata = [
            'other' => [
                'authparams' => $authparams,
                'tokenparams' => $tokenparams,
                'statedata' => $additionaldata,
            ],
        ];
        $event = user_authed::create($eventdata);
        $event->trigger();

        $redirect = (!empty($additionaldata['redirect'])) ? $additionaldata['redirect'] : '/auth/oidc/ucp.php';
        redirect(new url($redirect));
    }

    /**
     * Handle an authorization request response received from the configured OP.
     *
     * @param array $authparams Received parameters.
     */
    protected function handleauthresponse(array $authparams) {
        global $DB, $SESSION, $USER, $CFG;

        $sid = optional_param('session_state', '', PARAM_TEXT);

        if (!empty($authparams['error_description'])) {
            utils::debug('Authorization error.', __METHOD__, $authparams);
            redirect($CFG->wwwroot, get_string('errorauthgeneral', 'auth_oidc'), null, notification::NOTIFY_ERROR);
        }

        if (!isset($authparams['code'])) {
            utils::debug('No auth code received.', __METHOD__, $authparams);
            throw new moodle_exception('errorauthnoauthcode', 'auth_oidc');
        }

        if (!isset($authparams['state'])) {
            utils::debug('No state received.', __METHOD__, $authparams);
            $this->handlemissingstaterecord();
        }

        // Validate and expire state.
        $staterec = $DB->get_record('auth_oidc_state', ['state' => $authparams['state']]);
        if (empty($staterec)) {
            $this->handlemissingstaterecord();
        }

        $csrfverified = is_https() || !empty($CFG->sslproxy) || !empty($_COOKIE['auth_oidc_csrf']);
        if ($csrfverified) {
            $this->verify_csrf_cookie($staterec);
        }

        $orignonce = $staterec->nonce;
        $additionaldata = [];
        if (!empty($staterec->additionaldata)) {
            $additionaldata = @unserialize($staterec->additionaldata);
            if (!is_array($additionaldata)) {
                $additionaldata = [];
            }
        }
        $SESSION->stateadditionaldata = $additionaldata;
        $DB->delete_records('auth_oidc_state', ['id' => $staterec->id]);

        // Get token from auth code.
        $client = $this->get_oidcclient();
        $tokenparams = $client->tokenrequest($authparams['code']);
        if (!isset($tokenparams['id_token'])) {
            throw new moodle_exception('errorauthnoidtoken', 'auth_oidc');
        }

        // Decode and verify ID token.
        [$oidcuniqid, $idtoken] = $this->process_idtoken($tokenparams['id_token'], $orignonce);

        // Check restrictions.
        $passed = $this->checkrestrictions($idtoken);
        if ($passed !== true && empty($additionaldata['ignorerestrictions'])) {
            $errstr = 'User prevented from logging in due to restrictions.';
            utils::debug($errstr, __METHOD__, $idtoken);
            throw new moodle_exception('errorrestricted', 'auth_oidc');
        }

        // This is for setting the system API user.
        if (isset($additionaldata['justauth']) && $additionaldata['justauth'] === true) {
            $eventdata = [
                'other' => [
                    'authparams' => $authparams,
                    'tokenparams' => $tokenparams,
                    'statedata' => $additionaldata,
                ],
            ];
            $event = user_authed::create($eventdata);
            $event->trigger();

            if ($csrfverified && !empty($additionaldata['initiatinguserid'])) {
                $initiatinguser = core_user::get_user((int) $additionaldata['initiatinguserid']);
                if (
                    $initiatinguser && empty($initiatinguser->deleted) &&
                    (!isloggedin() || isguestuser())
                ) {
                    \core\session\manager::login_user($initiatinguser);
                }
            }

            if (!empty($additionaldata['redirect'])) {
                redirect(new url($additionaldata['redirect']));
            }

            return true;
        }

        // Check if OIDC user is already migrated.
        $tokenrec = $DB->get_record('auth_oidc_token', ['oidcuniqid' => $oidcuniqid]);

        // Determine who initiated this request. Prefer the user id stored against the state record over the live
        // session: the state record is only returned by a legitimate, single-use round trip through the OP, so it
        // can be trusted even when the session cookie did not survive the callback (e.g. SameSite=Lax blocking the
        // cross-site POST used by response_mode=form_post). Fall back to the live session for state records created
        // before this was captured.
        $linkinguser = null;
        if (!empty($additionaldata['initiatinguserid'])) {
            $linkinguser = core_user::get_user((int)$additionaldata['initiatinguserid']);
            if (!$linkinguser || !empty($linkinguser->deleted)) {
                $linkinguser = null;
            }
        } else if (isloggedin() && !isguestuser()) {
            $linkinguser = $USER;
        }

        if ($linkinguser && (empty($tokenrec) || (isset($linkinguser->auth) && $linkinguser->auth !== 'oidc'))) {
            // If the initiating user is trying to link a Microsoft 365 account or use it for OIDC, make sure the
            // current session actually belongs to them, restoring it if the cookie was dropped on the callback.
            if (!isloggedin() || isguestuser() || (int)$USER->id !== (int)$linkinguser->id) {
                \core\session\manager::login_user($linkinguser);
            }

            // Check if that Microsoft 365 account already exists in moodle.
            $oidcusername = $this->get_oidc_username_from_token_claim($idtoken);

            $userrec = $DB->count_records_sql(
                'SELECT COUNT(*)
                                                 FROM {user}
                                                WHERE username = ?
                                                      AND id != ?',
                [$oidcusername, $USER->id]
            );

            if (!empty($userrec)) {
                if (empty($additionaldata['redirect'])) {
                    $redirect = '/auth/oidc/ucp.php?o365accountconnected=true';
                } else if ($additionaldata['redirect'] == '/local/o365/ucp.php') {
                    $redirect = $additionaldata['redirect'] . '?action=connection&o365accountconnected=true';
                } else {
                    throw new moodle_exception('errorinvalidredirect_message', 'auth_oidc');
                }
                redirect(new url($redirect));
            }

            // If the user is already logged in we can treat this as a "migration" - a user switching to OIDC.
            $connectiononly = false;
            if (isset($additionaldata['connectiononly']) && $additionaldata['connectiononly'] === true) {
                $connectiononly = true;
            }
            $this->handlemigration($oidcuniqid, $authparams, $tokenparams, $idtoken, $connectiononly);
            $redirect = (!empty($additionaldata['redirect'])) ? $additionaldata['redirect'] : '/auth/oidc/ucp.php';
            redirect(new url($redirect));
        } else {
            // Otherwise it's a user logging in normally with OIDC.
            $this->handlelogin($oidcuniqid, $authparams, $tokenparams, $idtoken);
            if (!empty($additionaldata['wantsurl'])) {
                // Normalize to string in case it's a core\url object from unserialization.
                if ($additionaldata['wantsurl'] instanceof url) {
                    $wantsurl = $additionaldata['wantsurl']->out();
                } else {
                    $wantsurl = (string)$additionaldata['wantsurl'];
                }
                // Validate URL is local using safe domain comparison.
                if ($this->is_valid_local_url($wantsurl)) {
                    $SESSION->wantsurl = $wantsurl;
                }
            }
            if ($USER->id && $DB->record_exists('auth_oidc_token', ['userid' => $USER->id])) {
                $authoidsidrecord = new stdClass();
                $authoidsidrecord->userid = $USER->id;
                $authoidsidrecord->sid = $sid;
                $authoidsidrecord->timecreated = time();
                // Store the Moodle session id so logout.php can terminate the correct session directly,
                // without depending on the MoodleSession cookie being present on the IdP's logout request.
                $authoidsidrecord->sessionid = session_id();
                // Store the issuer so logout.php can verify that a front-channel logout request naming
                // this sid actually originates from the same IdP/tenant that issued it.
                $authoidsidrecord->iss = $idtoken->claim('iss');
                $DB->insert_record('auth_oidc_sid', $authoidsidrecord);
            }
            redirect(core_login_get_return_url());
        }
    }

    /**
     * Handle a user migration event.
     *
     * @param string $oidcuniqid A unique identifier for the user.
     * @param array $authparams Parameters received from the auth request.
     * @param array $tokenparams Parameters received from the token request.
     * @param jwt $idtoken A JWT object representing the received id_token.
     * @param bool $connectiononly Whether to just connect the user (true), or to connect and change login method (false).
     */
    protected function handlemigration($oidcuniqid, $authparams, $tokenparams, $idtoken, $connectiononly = false) {
        global $USER, $DB, $CFG;

        // Check if OIDC user is already connected to a Moodle user.
        $tokenrec = $DB->get_record('auth_oidc_token', ['oidcuniqid' => $oidcuniqid]);
        if (!empty($tokenrec)) {
            $existinguserparams = ['username' => $tokenrec->username, 'mnethostid' => $CFG->mnet_localhost_id];
            $existinguser = $DB->get_record('user', $existinguserparams);
            if (empty($existinguser)) {
                $DB->delete_records('auth_oidc_token', ['id' => $tokenrec->id]);
            } else {
                if ($USER->username === $tokenrec->username) {
                    // Already connected to current user.
                    if ($connectiononly !== true && $USER->auth !== 'oidc') {
                        // Update auth plugin.
                        $DB->update_record('user', (object)['id' => $USER->id, 'auth' => 'oidc']);
                        $USER = $DB->get_record('user', ['id' => $USER->id]);
                        $USER->auth = 'oidc';
                    }
                    $this->updatetoken($tokenrec->id, $authparams, $tokenparams);
                    return true;
                } else {
                    // OIDC user connected to user that is not us. Can't continue.
                    throw new moodle_exception('errorauthuserconnectedtodifferent', 'auth_oidc');
                }
            }
        }

        // Check if Moodle user is already connected to an OIDC user.
        $tokenrec = $DB->get_record('auth_oidc_token', ['userid' => $USER->id]);
        if (!empty($tokenrec)) {
            if ($tokenrec->oidcuniqid === $oidcuniqid) {
                // Already connected to current user.
                if ($connectiononly !== true && $USER->auth !== 'oidc') {
                    // Update auth plugin.
                    $DB->update_record('user', (object)['id' => $USER->id, 'auth' => 'oidc']);
                    $USER = $DB->get_record('user', ['id' => $USER->id]);
                    $USER->auth = 'oidc';
                }
                $this->updatetoken($tokenrec->id, $authparams, $tokenparams);
                return true;
            } else {
                throw new moodle_exception('errorauthuseralreadyconnected', 'auth_oidc');
            }
        }

        // Create token data.
        $tokenrec = $this->createtoken($oidcuniqid, $USER->username, $authparams, $tokenparams, $idtoken, $USER->id);

        $eventdata = [
            'objectid' => $USER->id,
            'userid' => $USER->id,
            'other' => [
                'username' => $USER->username,
                'userid' => $USER->id,
                'oidcuniqid' => $oidcuniqid,
            ],
        ];
        $event = \auth_oidc\event\user_connected::create($eventdata);
        $event->trigger();

        // Switch auth method, if requested.
        if ($connectiononly !== true) {
            if ($USER->auth !== 'oidc') {
                $DB->delete_records('auth_oidc_prevlogin', ['userid' => $USER->id]);
                $userrec = $DB->get_record('user', ['id' => $USER->id]);
                if (!empty($userrec)) {
                    $prevloginrec = [
                        'userid' => $userrec->id,
                        'method' => $userrec->auth,
                        'password' => $userrec->password,
                    ];
                    $DB->insert_record('auth_oidc_prevlogin', $prevloginrec);
                }
            }
            $DB->update_record('user', (object)['id' => $USER->id, 'auth' => 'oidc']);
            $USER = $DB->get_record('user', ['id' => $USER->id]);
            $USER->auth = 'oidc';
        }

        return true;
    }

    /**
     * Determines whether the given Microsoft Entra ID UPN is already matched to a Moodle user (and has not been completed).
     *
     * @param string $entraidupn The Microsoft Entra ID UPN to check for a match.
     * @return false|stdClass Either the matched Moodle user record, or false if not matched.
     */
    protected function check_for_matched($entraidupn) {
        global $DB;

        if (auth_oidc_is_local_365_installed()) {
            $entraidupn = trim($entraidupn);
            $sql = 'SELECT *
                      FROM {local_o365_connections}
                     WHERE ' . $DB->sql_equal('entraidupn', ':entraidupn', false);
            $match = $DB->get_record_sql($sql, ['entraidupn' => $entraidupn]);
            if (!empty($match) && \local_o365\utils::is_o365_connected($match->muserid) !== true) {
                return $DB->get_record('user', ['id' => $match->muserid]);
            }
        }

        return false;
    }

    /**
     * Check for an existing user object.
     * @param string $oidcuniqid The user object ID to look up.
     * @param string $username The original username.
     * @return string If there is an existing user object, return the username associated with it.
     *                If there is no existing user object, return the original username.
     */
    protected function check_objects($oidcuniqid, $username) {
        global $DB;

        $user = null;
        if (auth_oidc_is_local_365_installed()) {
            $sql = 'SELECT u.username
                      FROM {local_o365_objects} obj
                      JOIN {user} u ON u.id = obj.moodleid
                     WHERE obj.objectid = ? and obj.type = ?';
            $params = [$oidcuniqid, 'user'];
            $user = $DB->get_record_sql($sql, $params);
        }

        return (!empty($user)) ? $user->username : $username;
    }

    /**
     * Handle a login event.
     *
     * @param string $oidcuniqid A unique identifier for the user.
     * @param array $authparams Parameters received from the auth request.
     * @param array $tokenparams Parameters received from the token request.
     * @param jwt $idtoken A JWT object representing the received id_token.
     */
    protected function handlelogin(string $oidcuniqid, array $authparams, array $tokenparams, jwt $idtoken) {
        global $DB, $CFG;

        $tokenrec = $DB->get_record('auth_oidc_token', ['oidcuniqid' => $oidcuniqid]);

        // Do not continue if auth plugin is not enabled.
        if (!is_enabled_auth('oidc')) {
            throw new moodle_exception('erroroidcnotenabled', 'auth_oidc', null, null, '1');
        }

        // Find the latest real Microsoft username.
        $oidcusername = $this->get_oidc_username_from_token_claim($idtoken);

        $usernamechanged = false;
        if ($oidcusername && $tokenrec && strtolower($oidcusername) !== strtolower($tokenrec->useridentifier)) {
            $usernamechanged = true;
        }

        $existingmatching = null;
        if (auth_oidc_is_local_365_installed()) {
            if ($existingmatching = $DB->get_record('local_o365_objects', ['type' => 'user', 'objectid' => $oidcuniqid])) {
                $existinguser = core_user::get_user($existingmatching->moodleid);
                if (
                    $existinguser && strtolower($existingmatching->o365name) != strtolower($oidcusername) &&
                    $existinguser->username != strtolower($oidcusername)
                ) {
                    $usernamechanged = true;
                }
            }
        }

        $supportuseridentifierchangeconfig = auth_oidc_is_local_365_installed()
            ? get_config('local_o365', 'support_user_identifier_change')
            : 0;

        if (!empty($tokenrec)) {
            // Already connected user.
            if (empty($tokenrec->userid)) {
                // Existing token record, but missing the user ID.
                $user = null;
                if ($usernamechanged) {
                    $user = $DB->get_record('user', ['username' => strtolower($oidcusername)]);
                }
                if (empty($user)) {
                    $user = $DB->get_record('user', ['username' => $tokenrec->username]);
                }

                if (empty($user) || $user->username != strtolower($tokenrec->username)) {
                    // Token exists, but it doesn't have a valid username or username doesn't match token.
                    // In this case, delete the token, and try to process login again.
                    $DB->delete_records('auth_oidc_token', ['id' => $tokenrec->id]);
                    return $this->handlelogin($oidcuniqid, $authparams, $tokenparams, $idtoken);
                }
                $tokenrec->userid = $user->id;
                if ($usernamechanged) {
                    $tokenrec->useridentifier = strtolower($oidcusername);
                }
                $DB->update_record('auth_oidc_token', $tokenrec);
            } else {
                // Existing token with a user ID.
                $user = $DB->get_record('user', ['id' => $tokenrec->userid]);
                if (empty($user)) {
                    $failurereason = AUTH_LOGIN_NOUSER;
                    $eventdata = ['other' => ['username' => $tokenrec->username, 'reason' => $failurereason]];
                    $event = \core\event\user_login_failed::create($eventdata);
                    $event->trigger();
                    // Token is invalid, delete it.
                    $DB->delete_records('auth_oidc_token', ['id' => $tokenrec->id]);
                    return $this->handlelogin($oidcuniqid, $authparams, $tokenparams, $idtoken);
                }

                // Handle username change - update token, update connection.
                if ($usernamechanged) {
                    if ($supportuseridentifierchangeconfig != 1) {
                        // Username change is not supported, throw exception.
                        throw new moodle_exception('errorupnchangeisnotsupported', 'auth_oidc', null, null, '2');
                    }
                    $potentialduplicateuser = core_user::get_user_by_username(strtolower($oidcusername));
                    if ($potentialduplicateuser && $potentialduplicateuser->id != $tokenrec->userid) {
                        // Username already exists in another user, cannot change Moodle account username, throw exception.
                        throw new moodle_exception('erroruserwithusernamealreadyexists', 'auth_oidc', null, null, '2');
                    } else {
                        // Username does not exist or belongs to the same user:
                        // 1. can change Moodle account username (if the user uses auth_oidc),
                        // 2. can change token record.
                        if ($user->auth == 'oidc') {
                            $user->username = strtolower($oidcusername);
                            user_update_user($user, false);

                            $fullmessage = 'Attempt to change username of user ' . $user->id . ' from ' .
                                $tokenrec->useridentifier . ' to ' . strtolower($oidcusername);
                            $event = user_rename_attempt::create(['objectid' => $user->id, 'other' => $fullmessage,
                                'userid' => $user->id]);
                            $event->trigger();

                            $tokenrec->username = strtolower($oidcusername);
                        }

                        $tokenrec->useridentifier = $oidcusername;
                        $bindingusernameclaim = auth_oidc_get_binding_username_claim();
                        if (in_array($bindingusernameclaim, ['upn', 'auto'])) {
                            $tokenrec->oidcusername = $oidcusername;
                        }
                        $DB->update_record('auth_oidc_token', $tokenrec);
                    }

                    // Update local_o365_objects table.
                    if (auth_oidc_is_local_365_installed()) {
                        if (
                            $o365objectrecord = $DB->get_record(
                                'local_o365_objects',
                                ['moodleid' => $user->id, 'type' => 'user']
                            )
                        ) {
                            $o365objectrecord->o365name = $oidcusername;
                            $DB->update_record('local_o365_objects', $o365objectrecord);
                        }
                    }
                }
            }
            $username = $user->username;
            $this->updatetoken($tokenrec->id, $authparams, $tokenparams);
            $user = authenticate_user_login($username, '', true);

            if (!empty($user)) {
                // Look for plugins that want to add extra checks before user login is completed.
                $hook = new \auth_oidc\hook\before_login_completed($idtoken);
                di::get(\core\hook\manager::class)->dispatch($hook);

                complete_user_login($user);
            } else {
                // There was a problem in authenticate_user_login.
                throw new moodle_exception('errorauthgeneral', 'auth_oidc', null, null, '2');
            }
        } else if ($usernamechanged) {
            // User has connection record, but no token; and the user has been renamed in Microsoft.
            // In this case, we need to:
            // 1. attempt to update Moodle username,
            // 2. create token record,
            // 3. update connection record in local_o365_objects table.

            if ($supportuseridentifierchangeconfig != 1) {
                throw new moodle_exception('errorupnchangeisnotsupported', 'auth_oidc', null, null, '2');
            }

            $existinguser = core_user::get_user($existingmatching->moodleid);

            $username = $this->get_oidc_username_from_token_claim($idtoken);

            $originalupn = null;

            if (empty($username)) {
                $username = $oidcuniqid;

                // If upn claim is missing, it can mean either the IdP is not Microsoft Entra ID, or it's a guest user.
                if (auth_oidc_is_local_365_installed()) {
                    $apiclient = \local_o365\utils::get_api();
                    $userdetails = $apiclient->get_user($oidcuniqid);
                    if (
                        !is_null($userdetails) && isset($userdetails['userPrincipalName']) &&
                        stripos($userdetails['userPrincipalName'], '#EXT#') !== false && $idtoken->claim('unique_name')
                    ) {
                        $originalupn = $userdetails['userPrincipalName'];
                        $username = $idtoken->claim('unique_name');
                    }
                }
            }
            $username = trim(core_text::strtolower($username));

            // Update username.
            $userwithduplicateusername = core_user::get_user_by_username($username);
            if ($userwithduplicateusername) {
                // Cannot rename user, username already exists.
                throw new moodle_exception('erroruserwithusernamealreadyexists', 'auth_oidc', null, null, '2');
            } else {
                $originalusername = $existinguser->username;
                $existinguser->username = $username;
                user_update_user($existinguser, false);

                $fullmessage =
                    'Attempt to change username of user ' . $existinguser->id . ' from ' . $originalusername . ' to ' .
                    $username;
                $event = user_rename_attempt::create(['objectid' => $existinguser->id, 'other' => $fullmessage,
                    'userid' => $existinguser->id]);
                $event->trigger();
            }

            // Create token.
            $this->createtoken($oidcuniqid, $username, $authparams, $tokenparams, $idtoken, 0, $originalupn);

            // Update connection record in local_o365_objects table.
            if (auth_oidc_is_local_365_installed()) {
                $existingmatching->o365name = $oidcusername;
                $DB->update_record('local_o365_objects', $existingmatching);
            }

            $user = authenticate_user_login($username, '', true);

            if (!empty($user)) {
                // Look for plugins that want to add extra checks before user login is completed.
                $hook = new \auth_oidc\hook\before_login_completed($idtoken);
                di::get(\core\hook\manager::class)->dispatch($hook);

                complete_user_login($user);
            } else {
                // There was a problem in authenticate_user_login.
                throw new moodle_exception('errorauthgeneral', 'auth_oidc', null, null, '2');
            }
        } else {
            /* No existing token, user not connected. Possibilities:
                - Matched user.
                - New user (maybe create).
            */

            // Generate a Moodle username.
            $username = $this->get_oidc_username_from_token_claim($idtoken);

            $originalupn = null;

            if (empty($username)) {
                $username = $oidcuniqid;

                // If upn claim is missing, it can mean either the IdP is not Microsoft Entra ID, or it's a guest user.
                if (auth_oidc_is_local_365_installed()) {
                    $apiclient = \local_o365\utils::get_api();
                    $userdetails = $apiclient->get_user($oidcuniqid, true);
                    if (
                        !is_null($userdetails) && isset($userdetails['userPrincipalName']) &&
                        stripos($userdetails['userPrincipalName'], '#EXT#') !== false && $idtoken->claim('unique_name')
                    ) {
                        $originalupn = $userdetails['userPrincipalName'];
                        $username = $idtoken->claim('unique_name');
                    }
                }
            }

            // See if we have an object listing.
            $username = $this->check_objects($oidcuniqid, $username);
            $matchedwith = $this->check_for_matched($username);
            if (!empty($matchedwith)) {
                if ($matchedwith->auth != 'oidc') {
                    $matchedwith->entraidupn = $username;
                    throw new moodle_exception('errorusermatched', 'auth_oidc', null, $matchedwith);
                }
                // The matched Moodle user is already set to auth 'oidc': bind the login to that user's own
                // username rather than the Microsoft-derived one, which may not match it (e.g. a manual match
                // keyed on the full UPN while the Moodle username is only the UPN prefix).
                $username = $matchedwith->username;
            }
            $username = trim(core_text::strtolower($username));
            $tokenrec = $this->createtoken($oidcuniqid, $username, $authparams, $tokenparams, $idtoken, 0, $originalupn);

            $existinguserparams = ['username' => $username, 'mnethostid' => $CFG->mnet_localhost_id];
            if ($DB->record_exists('user', $existinguserparams) !== true) {
                // User does not exist. Create user if site allows, otherwise fail.
                if (empty($CFG->authpreventaccountcreation)) {
                    if (!$CFG->allowaccountssameemail) {
                        $userinfo = $this->get_userinfo($username);
                        if ($DB->count_records('user', ['email' => $userinfo['email'], 'deleted' => 0]) > 0) {
                            throw new moodle_exception('errorauthloginfaileddupemail', 'auth_oidc', null, null, '1');
                        }
                    }
                    $user = create_user_record($username, '', 'oidc');

                    // Trigger user_created event.
                    $eventdata = [
                        'objectid' => $user->id,
                        'userid' => $user->id,
                        'relateduserid' => $user->id,
                    ];
                    $event = user_created::create($eventdata);
                    $event->trigger();
                } else {
                    // Trigger login failed event.
                    $failurereason = AUTH_LOGIN_NOUSER;
                    $eventdata = ['other' => ['username' => $username, 'reason' => $failurereason]];
                    $event = \core\event\user_login_failed::create($eventdata);
                    $event->trigger();
                    throw new moodle_exception('errorauthloginfailednouser', 'auth_oidc', null, null, '1');
                }
            }

            $user = authenticate_user_login($username, '', true);

            if (!empty($user)) {
                $tokenrec = $DB->get_record('auth_oidc_token', ['id' => $tokenrec->id]);
                // This should be already done in auth_plugin_oidc::user_authenticated_hook, but just in case...
                if (!empty($tokenrec) && empty($tokenrec->userid)) {
                    $updatedtokenrec = new stdClass();
                    $updatedtokenrec->id = $tokenrec->id;
                    $updatedtokenrec->userid = $user->id;
                    $DB->update_record('auth_oidc_token', $updatedtokenrec);
                }

                // Look for plugins that want to add extra checks before user login is completed.
                $hook = new \auth_oidc\hook\before_login_completed($idtoken);
                di::get(\core\hook\manager::class)->dispatch($hook);

                complete_user_login($user);
            } else {
                // There was a problem in authenticate_user_login. Clean up incomplete token record.
                if (!empty($tokenrec)) {
                    $DB->delete_records('auth_oidc_token', ['id' => $tokenrec->id]);
                }

                redirect($CFG->wwwroot, get_string('errorauthgeneral', 'auth_oidc'), null, notification::NOTIFY_ERROR);
            }
        }
        return true;
    }
}
