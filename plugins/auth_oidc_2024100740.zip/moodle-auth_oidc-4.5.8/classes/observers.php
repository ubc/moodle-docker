<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Event observer handlers for auth_oidc plugin.
 *
 * @package auth_oidc
 * @author James McQuillan <james.mcquillan@remote-learner.net>
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @copyright (C) 2014 onwards Microsoft, Inc. (http://microsoft.com/)
 */

namespace auth_oidc;

use auth_oidc\loginflow\authcode;
use core\event\user_deleted;
use core\event\user_loggedout;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/lib/filelib.php');

/**
 * Handles events.
 */
class observers {
    /**
     * Handle user_deleted event - clean up calendar subscriptions.
     *
     * @param user_deleted $event The triggered event.
     * @return bool Success/Failure.
     */
    public static function handle_user_deleted(user_deleted $event) {
        global $DB;
        $userid = $event->objectid;
        return $DB->delete_records('auth_oidc_token', ['userid' => $userid]);
    }

    /**
     * Handle user_loggedout event - invalidate any pending OIDC state tied to the CSRF cookie
     * of the session that just logged out, so a still-in-flight callback (e.g. admin consent)
     * cannot silently re-authenticate a user who explicitly logged out.
     *
     * @param user_loggedout $event The triggered event.
     * @return bool Success/Failure.
     */
    public static function handle_user_loggedout(user_loggedout $event) {
        global $DB;

        $csrfcookie = $_COOKIE['auth_oidc_csrf'] ?? null;
        if (is_string($csrfcookie) && $csrfcookie !== '') {
            $DB->delete_records('auth_oidc_state', ['sesskey' => $csrfcookie]);
        }

        (new authcode())->clear_csrf_cookie();

        return true;
    }
}
