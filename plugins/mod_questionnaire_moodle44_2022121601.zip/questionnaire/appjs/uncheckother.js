(function(t) {
    t.toggleRatebox = function($event, $fieldkey) {
    }
})(this);