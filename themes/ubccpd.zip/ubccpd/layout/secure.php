<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * The secure layout.
 *
 * @package   theme_ubccpd
 * @copyright 2013 Moodle, moodle.org
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

// Get the HTML for the settings bits.
$html = theme_ubccpd_get_html_for_settings($OUTPUT, $PAGE);

echo $OUTPUT->doctype() ?>
<html <?php echo $OUTPUT->htmlattributes(); ?>>
<head>
    <title><?php echo $OUTPUT->page_title(); ?></title>
    <link rel="shortcut icon" href="<?php echo $OUTPUT->favicon(); ?>" />
    <?php echo $OUTPUT->standard_head_html() ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Google fonts -->
    <link href="//fonts.googleapis.com/css?family=Open Sans:400,600,700,Bold,italic" rel="stylesheet" type="text/css"/>

    <!-- Awesome fonts -->
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
</head>

<body <?php echo $OUTPUT->body_attributes(); ?>>

<?php echo $OUTPUT->standard_top_of_body_html() ?>

<header role="banner" class="navbar navbar-fixed-top moodle-has-zindex">
    <nav role="navigation" class="navbar-inner">
        <div class="container-fluid">
            <a class="brand" href="<?php echo $CFG->wwwroot;?>"><img class="logo-img-lg" src="<?php echo $OUTPUT->pix_url('logo', 'theme'); ?>" alt="<?php echo get_string('organizationdivision', 'theme_ubccpd'); ?>"  /><img class="logo-img-sm" src="<?php echo $OUTPUT->pix_url('logo-sm', 'theme'); ?>" alt="<?php echo get_string('organizationdivision', 'theme_ubccpd'); ?>"  /></a>
            <a class="btn btn-navbar" data-toggle="workaround-collapse" data-target=".nav-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            <div class="organization-secondary-logo">
                <img class="secondary-logo-img" src="<?php echo $OUTPUT->pix_url('second-logo', 'theme'); ?>" alt="<?php echo get_string('secorganizationtitle', 'theme_ubccpd'); ?>"  />
            </div>
            <div class="organization-third-logo">
                <img class="third-logo-img" src="<?php echo $OUTPUT->pix_url('third-logo', 'theme'); ?>" alt="<?php echo get_string('thirdorganizationtitle', 'theme_ubccpd'); ?>"  />
            </div>
            <div class="organization-branding">
                <span class="organization-sub"><?php echo get_string('organizationsub', 'theme_ubccpd'); ?></span>
                <span class="organziation-div"><?php echo get_string('organizationdivision', 'theme_ubccpd'); ?></span>
            </div>
            <div class="nav-collapse collapse">
                 <ul class="custom-nav nav pull-right">
                	<li class="navbar-text"><?php echo $OUTPUT->login_info() ?></li>
                </ul>
                <ul class="nav pull-right">
                    <li><?php echo $OUTPUT->page_heading_menu(); ?></li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<div id="page" class="container-fluid">

    <header id="page-header" class="clearfix">
        <?php echo $html->heading; ?>
    </header>

    <div id="page-content" class="row-fluid">
        <div id="region-bs-main-and-pre" class="span9">
            <div class="row-fluid">
                <section id="region-main" class="span8 pull-right">
                    <?php echo $OUTPUT->main_content(); ?>
                </section>
                <?php echo $OUTPUT->blocks('side-pre', 'span4 desktop-first-column'); ?>
            </div>
        </div>
        <?php echo $OUTPUT->blocks('side-post', 'span3'); ?>
    </div>

    <?php echo $OUTPUT->standard_end_of_body_html() ?>

</div>
</body>
</html>