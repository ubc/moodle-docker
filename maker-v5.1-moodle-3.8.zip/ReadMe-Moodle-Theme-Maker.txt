Moodle 3.8 Theme Maker
=======================================================================
Maker is a responsive Moodle theme designed for online learning.

Theme name:
=======================================================================
Maker

Theme version:
=======================================================================
v5.1

Release Date:
=======================================================================
16 April 2020

Author: 
=======================================================================
3rd Wave Media (http://elearning.3rdwavemedia.com/)

Licenses: 
=======================================================================
http://elearning.3rdwavemedia.com/licenses/

Moodle version required:
=======================================================================
Moodle 3.8

Theme Parents
=======================================================================
Moodle Boost Theme

Installation:
=======================================================================
1) Download the theme zip file
2) Extract the /maker/ folder and the files.
3) Upload the /maker/ folder to your hosting server's Moodle theme directory:
   Your Moodle installation > theme > maker 
4) Log into your Moodle site as an admin, and navigate to the theme selector:
   Settings > Site administration > Appearance > Themes > Theme selector
5) Click "use theme" next to the maker theme to activate

Support:
=======================================================================
Without prior agreement, the price of the theme does not include additional support or consultancy.

Contact:
=======================================================================
Web: http://elearning.3rdwavemedia.com/
Email: elearning@3rdwavemedia.com
Twitter: @3rdwave_moodle
