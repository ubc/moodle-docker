<?php

namespace enrol_arlo\Arlo\AuthAPI\Exception;


class XMLDeserializerException extends \Exception {}
