<?php namespace enrol_arlo\Arlo\AuthAPI\Enum;

class IntegrationData {

    /** @var string VendorID used to identify this integration. */
    const VendorID = 'ArloMoodlePlugin';

}
