<?php

namespace enrol_arlo\Arlo\AuthAPI\Resource;

/**
 * Class ContactInfo
 * @package enrol_arlo\Arlo\AuthAPI\Resource
 */
class ContactInfo extends AbstractResource {
    public $ContactID;
    public $UniqueIdentifier;
}